import { TelegramWebApp, TelegramUser } from "@/types";

export class TelegramService {
  private webApp: TelegramWebApp | null = null;

  constructor() {
    if (typeof window !== "undefined" && window.Telegram?.WebApp) {
      this.webApp = window.Telegram.WebApp;
      this.webApp.ready();
      this.webApp.expand();
    }
  }

  get isAvailable(): boolean {
    return this.webApp !== null;
  }

  get user(): TelegramUser | null {
    return this.webApp?.initDataUnsafe.user || null;
  }

  get startParam(): string | null {
    return this.webApp?.initDataUnsafe.start_param || null;
  }

  get colorScheme(): "light" | "dark" {
    return this.webApp?.colorScheme || "dark";
  }

  close(): void {
    this.webApp?.close();
  }

  // Mock implementation for development
  getMockUser(): TelegramUser {
    return {
      id: 123456789,
      first_name: "Test",
      last_name: "User",
      username: "testuser",
      language_code: "en"
    };
  }

  // Get user for API calls - use mock in development
  getApiUser(): TelegramUser {
    if (this.isAvailable && this.user) {
      return this.user;
    }
    // Return mock user for development
    return this.getMockUser();
  }
}

export const telegramService = new TelegramService();
