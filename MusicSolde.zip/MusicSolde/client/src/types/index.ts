export interface SearchResult {
  id: string;
  title: string;
  artist: string;
  duration: string;
  type: "music" | "video";
  price: string;
  lpCost: number;
}

export interface User {
  id: string;
  tgId: string;
  username?: string;
  firstName?: string;
  lpBalance: number;
  isSubscribed: boolean;
  refCode: string;
}

export interface Download {
  id: string;
  title: string;
  artist?: string;
  duration?: string;
  kind: "music" | "video";
  lpCost: number;
  createdAt: string;
}

export interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
}

export interface TelegramWebApp {
  initData: string;
  initDataUnsafe: {
    user?: TelegramUser;
    start_param?: string;
  };
  version: string;
  platform: string;
  colorScheme: "light" | "dark";
  themeParams: {
    link_color: string;
    button_color: string;
    button_text_color: string;
    secondary_bg_color: string;
    hint_color: string;
    bg_color: string;
    text_color: string;
  };
  isExpanded: boolean;
  viewportHeight: number;
  viewportStableHeight: number;
  ready: () => void;
  close: () => void;
  expand: () => void;
}

declare global {
  interface Window {
    Telegram?: {
      WebApp: TelegramWebApp;
    };
  }
}
