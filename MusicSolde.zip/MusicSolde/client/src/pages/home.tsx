import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { telegramService } from "@/lib/telegram";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { User, SearchResult } from "@/types";
import SubscriptionGate from "@/components/subscription-gate";
import MediaToggle from "@/components/media-toggle";
import SearchBar from "@/components/search-bar";
import SearchResults from "@/components/search-results";
import DownloadHistory from "@/components/download-history";
import LoadingOverlay from "@/components/loading-overlay";
import { useToast } from "@/hooks/use-toast";
import { Download, Music, Share, History, Coins } from "lucide-react";

export default function Home() {
  const [currentMode, setCurrentMode] = useState<"music" | "video">("music");
  const [searchQuery, setSearchQuery] = useState("");
  const [showHistory, setShowHistory] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState("");
  const { toast } = useToast();

  const tgUser = telegramService.getApiUser();

  // Initialize user
  const { data: userData, isLoading: userLoading } = useQuery({
    queryKey: ["/api/webapp/init"],
    queryFn: async () => {
      const res = await apiRequest("POST", "/api/webapp/init", {
        tgId: tgUser.id.toString(),
        username: tgUser.username,
        firstName: tgUser.first_name,
        lastName: tgUser.last_name,
        refCode: telegramService.startParam
      });
      return res.json() as Promise<{ user: User }>;
    },
  });

  // Search results
  const { data: searchData, isLoading: searchLoading } = useQuery({
    queryKey: ["/api/webapp/search", searchQuery, currentMode],
    queryFn: async () => {
      if (!searchQuery.trim()) return { results: [] };
      const res = await fetch(`/api/webapp/search?query=${encodeURIComponent(searchQuery)}&type=${currentMode}`);
      return res.json() as Promise<{ results: SearchResult[] }>;
    },
    enabled: searchQuery.trim().length > 0,
  });

  // Download mutation
  const downloadMutation = useMutation({
    mutationFn: async (params: { result: SearchResult }) => {
      const { result } = params;
      const res = await apiRequest("POST", "/api/webapp/download", {
        tgId: tgUser.id.toString(),
        resultId: result.id,
        title: result.title,
        artist: result.artist,
        duration: result.duration,
        type: result.type
      });
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Téléchargement terminé!",
        description: `${data.download.title} a été téléchargé avec succès.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/webapp/init"] });
      setIsLoading(false);
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erreur de téléchargement",
        description: error.message || "LP insuffisants! Parrainez des amis pour gagner plus de points.",
      });
      setIsLoading(false);
    },
  });

  // Subscription check mutation
  const subscriptionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/webapp/check-subscription", {
        tgId: tgUser.id.toString()
      });
      return res.json();
    },
    onSuccess: (data) => {
      if (data.isSubscribed) {
        toast({
          title: "Abonnement vérifié!",
          description: "Vous pouvez maintenant utiliser l'application.",
        });
        queryClient.invalidateQueries({ queryKey: ["/api/webapp/init"] });
      } else {
        toast({
          variant: "destructive",
          title: "Abonnement requis",
          description: "Veuillez vous abonner au canal pour continuer.",
        });
      }
    },
  });

  // Referral link mutation
  const referralMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/webapp/ref-link", {
        tgId: tgUser.id.toString()
      });
      return res.json();
    },
    onSuccess: (data) => {
      navigator.clipboard.writeText(data.referralLink).then(() => {
        toast({
          title: "Lien copié!",
          description: "Le lien de parrainage a été copié dans le presse-papiers.",
        });
      }).catch(() => {
        toast({
          title: "Lien de parrainage",
          description: data.referralLink,
        });
      });
    },
  });

  const handleDownload = async (result: SearchResult) => {
    if (result.type === "video" && userData && userData.user.lpBalance < result.lpCost) {
      toast({
        variant: "destructive",
        title: "LP insuffisants!",
        description: "Parrainez des amis pour gagner plus de points.",
      });
      return;
    }

    setIsLoading(true);
    setLoadingMessage("Téléchargement en cours...");
    
    // Simulate download progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 20;
      if (progress >= 90) {
        clearInterval(interval);
        downloadMutation.mutate({ result });
      }
    }, 200);
  };

  const handleSubscriptionCheck = () => {
    subscriptionMutation.mutate();
  };

  const handleReferralShare = () => {
    referralMutation.mutate();
  };

  if (userLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="glassmorphism rounded-2xl p-8 text-center">
          <div className="w-16 h-16 mx-auto mb-4 animate-spin">
            <div className="w-full h-full border-4 border-primary/30 border-t-primary rounded-full"></div>
          </div>
          <p className="text-foreground font-medium">Chargement...</p>
        </div>
      </div>
    );
  }

  if (!userData?.user.isSubscribed) {
    return <SubscriptionGate onCheck={handleSubscriptionCheck} />;
  }

  return (
    <div className="h-screen flex flex-col relative overflow-hidden">
      {/* Header */}
      <header className="h-16 flex items-center justify-center px-4 relative glassmorphism border-b border-border/20" data-testid="header">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center animate-glow">
            <Download className="text-primary-foreground" size={20} />
          </div>
          <h1 className="text-xl font-bold text-foreground bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Tubidy Free DL
          </h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-4 py-4 flex flex-col min-h-0 space-y-4">
        {/* Media Type Toggle */}
        <MediaToggle 
          currentMode={currentMode} 
          onModeChange={setCurrentMode}
        />

        {/* Search Bar */}
        <SearchBar 
          query={searchQuery}
          onQueryChange={setSearchQuery}
        />

        {/* Search Results - Fixed height container */}
        <div className="flex-1 min-h-0">
          <SearchResults
            results={searchData?.results || []}
            isLoading={searchLoading}
            onDownload={handleDownload}
          />
        </div>
      </main>

      {/* Footer */}
      <footer className="h-20 px-4 py-3" data-testid="footer">
        <div className="glassmorphism rounded-2xl p-4 flex items-center justify-between border border-border/30">
          <div className="flex items-center space-x-4">
            {/* LP Balance */}
            <div className="flex items-center space-x-2" data-testid="lp-balance">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center animate-pulse-slow">
                <Coins className="text-primary-foreground" size={18} />
              </div>
              <div className="flex flex-col">
                <span className="text-xs text-muted-foreground">Solde</span>
                <span className="font-bold text-foreground text-lg">
                  {userData?.user.lpBalance.toFixed(1)} LP
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            {/* Referral Button */}
            <button 
              onClick={handleReferralShare}
              className="bg-gradient-to-r from-accent to-primary hover:from-accent/90 hover:to-primary/90 text-white px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 hover:scale-105 flex items-center space-x-2 shadow-lg"
              data-testid="button-referral"
            >
              <Share size={14} />
              <span>Parrainer</span>
            </button>
            
            {/* History Button */}
            <button 
              onClick={() => setShowHistory(true)}
              className="bg-muted/50 hover:bg-muted/70 text-muted-foreground hover:text-foreground px-3 py-3 rounded-xl transition-all duration-200 hover:scale-105 border border-border/30"
              data-testid="button-history"
            >
              <History size={18} />
            </button>
          </div>
        </div>
      </footer>

      {/* Download History Modal */}
      {showHistory && (
        <DownloadHistory 
          tgId={tgUser.id.toString()}
          onClose={() => setShowHistory(false)} 
        />
      )}

      {/* Loading Overlay */}
      {isLoading && (
        <LoadingOverlay message={loadingMessage} />
      )}

      {/* Disclaimer */}
      <div className="absolute bottom-20 left-4 right-4 text-center" data-testid="disclaimer">
        <p className="text-xs text-muted-foreground">
          Uniquement contenus libres de droits. Les autres contenus sont bloqués.
        </p>
      </div>
    </div>
  );
}
