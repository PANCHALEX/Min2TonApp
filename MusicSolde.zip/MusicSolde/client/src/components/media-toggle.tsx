import { Music, Video } from "lucide-react";

interface MediaToggleProps {
  currentMode: "music" | "video";
  onModeChange: (mode: "music" | "video") => void;
}

export default function MediaToggle({ currentMode, onModeChange }: MediaToggleProps) {
  return (
    <div className="glassmorphism rounded-2xl p-1 flex border border-border/30 shadow-lg" data-testid="media-toggle">
      <button
        onClick={() => onModeChange("music")}
        className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all duration-200 flex items-center justify-center space-x-2 ${
          currentMode === "music"
            ? "bg-gradient-to-r from-accent to-primary text-white shadow-lg"
            : "text-muted-foreground hover:text-foreground hover:bg-white/5"
        }`}
        data-testid="button-music"
      >
        <Music size={16} />
        <span>Musiques</span>
      </button>
      <button
        onClick={() => onModeChange("video")}
        className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all duration-200 flex items-center justify-center space-x-2 ${
          currentMode === "video"
            ? "bg-gradient-to-r from-primary to-accent text-white shadow-lg"
            : "text-muted-foreground hover:text-foreground hover:bg-white/5"
        }`}
        data-testid="button-video"
      >
        <Video size={16} />
        <span>Vidéos</span>
      </button>
    </div>
  );
}
