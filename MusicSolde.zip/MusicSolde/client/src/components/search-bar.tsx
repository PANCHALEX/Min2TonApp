import { Search } from "lucide-react";

interface SearchBarProps {
  query: string;
  onQueryChange: (query: string) => void;
}

export default function SearchBar({ query, onQueryChange }: SearchBarProps) {
  return (
    <div className="relative" data-testid="search-bar">
      <div className="glassmorphism rounded-2xl p-4 border border-border/30 shadow-lg">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={20} />
          <input 
            type="text" 
            value={query}
            onChange={(e) => onQueryChange(e.target.value)}
            placeholder="Nom de la musique ou vidéo…" 
            className="w-full pl-12 pr-4 py-4 bg-input/50 border border-border/50 rounded-xl text-foreground placeholder-muted-foreground focus:outline-none search-glow transition-all duration-200 font-medium focus:bg-input/70 focus:border-primary/50"
            data-testid="input-search"
          />
        </div>
      </div>
    </div>
  );
}
