import { SearchResult } from "@/types";
import { Music, Video, Download, Search } from "lucide-react";

interface SearchResultsProps {
  results: SearchResult[];
  isLoading: boolean;
  onDownload: (result: SearchResult) => void;
}

export default function SearchResults({ results, isLoading, onDownload }: SearchResultsProps) {
  if (isLoading) {
    return (
      <div className="flex-1 min-h-0 flex items-center justify-center">
        <div className="glassmorphism rounded-2xl p-8 text-center">
          <div className="w-16 h-16 mx-auto mb-4 animate-spin">
            <div className="w-full h-full border-4 border-primary/30 border-t-primary rounded-full"></div>
          </div>
          <p className="text-foreground font-medium">Recherche en cours...</p>
        </div>
      </div>
    );
  }

  if (results.length === 0) {
    return (
      <div className="flex-1 min-h-0 flex items-center justify-center">
        <div className="glassmorphism rounded-2xl p-8 text-center">
          <div className="w-16 h-16 mx-auto mb-4 bg-muted/30 rounded-full flex items-center justify-center">
            <Search className="text-muted-foreground" size={24} />
          </div>
          <p className="text-foreground font-medium mb-2">Aucun résultat</p>
          <p className="text-muted-foreground text-sm">
            Essayez de rechercher votre musique ou vidéo préférée
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full" data-testid="search-results">
      <div className="h-full overflow-y-auto hide-scroll space-y-3 pb-4">
        {results.slice(0, 4).map((result) => (
          <div 
            key={result.id}
            className="glassmorphism rounded-2xl p-4 flex items-center space-x-4 hover:bg-white/10 transition-all duration-200 border border-border/20"
            data-testid={`card-result-${result.id}`}
          >
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg">
              {result.type === "music" ? (
                <Music className="text-primary-foreground" size={22} />
              ) : (
                <Video className="text-primary-foreground" size={22} />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-foreground truncate text-base" data-testid={`text-title-${result.id}`}>
                {result.title}
              </h3>
              <p className="text-sm text-muted-foreground truncate font-medium" data-testid={`text-artist-${result.id}`}>
                {result.artist}
              </p>
              <p className="text-xs text-muted-foreground" data-testid={`text-duration-${result.id}`}>
                {result.duration}
              </p>
            </div>
            <div className="flex flex-col items-end space-y-2">
              <span 
                className={`text-xs px-3 py-1 rounded-full font-medium ${
                  result.type === "music" 
                    ? "bg-accent/20 text-accent border border-accent/30" 
                    : "bg-primary/20 text-primary border border-primary/30"
                }`}
                data-testid={`text-price-${result.id}`}
              >
                {result.price}
              </span>
              <button 
                onClick={() => onDownload(result)}
                className="bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 text-white px-4 py-2 rounded-xl text-sm font-bold transition-all duration-200 hover:scale-105 flex items-center space-x-2 shadow-lg"
                data-testid={`button-download-${result.id}`}
              >
                <Download size={14} />
                <span>Télécharger</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
