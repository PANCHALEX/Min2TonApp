import { Bell } from "lucide-react";

interface SubscriptionGateProps {
  onCheck: () => void;
}

export default function SubscriptionGate({ onCheck }: SubscriptionGateProps) {
  const handleSubscribe = () => {
    // In real implementation, this would open the Telegram channel
    console.log("Opening Telegram channel...");
    window.open("https://t.me/your_channel", "_blank");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-md bg-black/60" data-testid="subscription-gate">
      <div className="glassmorphism rounded-3xl p-8 w-full max-w-sm text-center space-y-6 animate-float border border-border/30 shadow-2xl">
        <div className="w-20 h-20 mx-auto bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center mb-6 animate-glow shadow-lg">
          <Bell className="text-white" size={28} />
        </div>
        <div className="space-y-3">
          <h3 className="text-2xl font-bold text-foreground">
            Abonne-toi pour continuer
          </h3>
          <p className="text-muted-foreground text-sm leading-relaxed">
            Rejoins notre canal pour accéder à des milliers de musiques gratuites et vidéos premium
          </p>
        </div>
        <div className="space-y-3">
          <button 
            onClick={handleSubscribe}
            className="w-full bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 text-white font-bold py-4 px-4 rounded-2xl transition-all duration-200 hover:scale-105 shadow-lg"
            data-testid="button-subscribe"
          >
            S'abonner au canal
          </button>
          <button 
            onClick={onCheck}
            className="w-full bg-muted/50 hover:bg-muted/70 text-foreground font-medium py-3 px-4 rounded-2xl transition-all duration-200 border border-border/30"
            data-testid="button-check-subscription"
          >
            J'ai abonné
          </button>
        </div>
      </div>
    </div>
  );
}
