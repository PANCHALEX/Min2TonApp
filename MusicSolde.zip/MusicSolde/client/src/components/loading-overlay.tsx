interface LoadingOverlayProps {
  message?: string;
}

export default function LoadingOverlay({ message = "Téléchargement en cours..." }: LoadingOverlayProps) {
  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center backdrop-blur-md bg-black/60" data-testid="loading-overlay">
      <div className="glassmorphism rounded-3xl p-8 text-center border border-border/30 shadow-2xl">
        <div className="w-20 h-20 mx-auto mb-6 animate-spin">
          <div className="w-full h-full border-4 border-primary/30 border-t-primary rounded-full"></div>
        </div>
        <p className="text-foreground font-bold mb-6 text-lg" data-testid="text-loading-message">
          {message}
        </p>
        <div className="w-56 h-3 bg-muted/50 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-primary via-accent to-primary rounded-full transition-all duration-500 animate-pulse shadow-lg"
            style={{ width: "85%" }}
            data-testid="progress-bar"
          />
        </div>
      </div>
    </div>
  );
}
