import { useQuery } from "@tanstack/react-query";
import { Download } from "@/types";
import { X, Music, Video } from "lucide-react";

interface DownloadHistoryProps {
  tgId: string;
  onClose: () => void;
}

export default function DownloadHistory({ tgId, onClose }: DownloadHistoryProps) {
  const { data: historyData, isLoading } = useQuery({
    queryKey: ["/api/webapp/history", tgId],
    queryFn: async () => {
      const res = await fetch(`/api/webapp/history/${tgId}`);
      return res.json() as Promise<{ downloads: Download[] }>;
    },
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      return "Il y a moins d'une heure";
    } else if (diffInHours < 24) {
      return `Il y a ${diffInHours}h`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return `Il y a ${diffInDays}j`;
    }
  };

  return (
    <div 
      className="fixed inset-0 z-40 flex items-center justify-center p-4 backdrop-blur-sm bg-black/50"
      onClick={(e) => e.target === e.currentTarget && onClose()}
      data-testid="download-history"
    >
      <div className="glassmorphism rounded-2xl p-6 w-full max-w-md h-96 flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Historique</h3>
          <button 
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
            data-testid="button-close-history"
          >
            <X size={20} />
          </button>
        </div>
        
        <div className="flex-1 space-y-3 overflow-y-auto hide-scroll">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <div className="w-8 h-8 animate-spin">
                <div className="w-full h-full border-4 border-primary/30 border-t-primary rounded-full"></div>
              </div>
            </div>
          ) : historyData?.downloads.length === 0 ? (
            <div className="flex items-center justify-center h-full">
              <p className="text-muted-foreground text-center">Aucun téléchargement</p>
            </div>
          ) : (
            historyData?.downloads.map((download) => (
              <div 
                key={download.id}
                className="glassmorphism rounded-xl p-3 flex items-center space-x-3 hover:bg-white/20 transition-all cursor-pointer"
                data-testid={`history-item-${download.id}`}
              >
                <div className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center">
                  {download.kind === "music" ? (
                    <Music className="text-accent" size={18} />
                  ) : (
                    <Video className="text-primary" size={18} />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground truncate" data-testid={`text-download-title-${download.id}`}>
                    {download.title}
                  </p>
                  <p className="text-xs text-muted-foreground" data-testid={`text-download-date-${download.id}`}>
                    {formatDate(download.createdAt)}
                  </p>
                </div>
                <span 
                  className={`text-xs px-2 py-1 rounded-full ${
                    download.kind === "music" 
                      ? "bg-accent/20 text-accent" 
                      : "bg-primary/20 text-primary"
                  }`}
                  data-testid={`text-download-type-${download.id}`}
                >
                  {download.lpCost === 0 ? "Gratuit" : `${download.lpCost} LP`}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
