# Overview

This is a Telegram Mini-App (WebApp) that provides a media download service similar to Tubidy, offering both music and video content. The application features a freemium model where music downloads are free while videos cost LP (loyalty points). Users start with 10 LP and can earn more through referrals. The app includes a subscription gate that requires users to join a Telegram channel before accessing content.

The system is built as a full-stack TypeScript application with a React frontend, Express.js backend, and PostgreSQL database, designed to run within the Telegram ecosystem as a WebApp.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React SPA**: Single-page application using React 18 with Vite as the build tool
- **UI Framework**: Custom component library built on Radix UI primitives with Tailwind CSS
- **State Management**: TanStack Query for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with custom CSS variables for theming, glassmorphism design aesthetic
- **Mobile-First**: Responsive design optimized for mobile devices within Telegram WebApp

## Backend Architecture
- **Express.js Server**: RESTful API server with TypeScript
- **Database Layer**: Drizzle ORM with PostgreSQL (Neon serverless)
- **API Structure**: Modular route handling with centralized error handling
- **Storage Interface**: Abstracted storage layer for database operations
- **Mock Services**: Tubidy search service with mock data for development

## Database Design
- **Users Table**: Stores Telegram user data, LP balance, subscription status, and referral codes
- **Referrals Table**: Tracks referral relationships and validation status
- **LP Transactions Table**: Audit trail for all LP balance changes with reasons
- **Downloads Table**: History of all user downloads with metadata
- **Relations**: Users can have multiple referrals, transactions, and downloads

## Authentication & Security
- **Telegram WebApp Auth**: Uses Telegram's initData with HMAC signature verification
- **Session Management**: Stateless authentication using Telegram user data
- **Subscription Gate**: Server-side verification of Telegram channel membership
- **Environment-based Config**: Separate development and production configurations

## External Integrations
- **Telegram Bot API**: For channel subscription verification and bot interactions
- **Telegram WebApp API**: For user authentication and app lifecycle management
- **Neon Database**: Serverless PostgreSQL for production data storage
- **Tubidy Service**: Content scraping service (currently mocked) for media search

## Key Features
- **Referral System**: Deep-link based referral tracking with LP rewards
- **LP Economy**: Point-based system for video purchases (2 LP per video)
- **Download History**: User-specific download tracking and history
- **Responsive Search**: Real-time search with type-ahead for music/video content
- **Glassmorphism UI**: Modern dark theme with glass-effect components optimized for mobile

## Development Setup
- **Monorepo Structure**: Shared types and schema between client/server
- **Hot Reloading**: Vite dev server with Express API proxy
- **Database Migrations**: Drizzle Kit for schema management and migrations
- **TypeScript**: Strict type checking across the entire application