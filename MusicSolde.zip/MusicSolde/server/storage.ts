import { users, referrals, lpTransactions, downloads, type User, type InsertUser, type Referral, type InsertReferral, type LpTransaction, type InsertLpTransaction, type Download, type InsertDownload } from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByTgId(tgId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(tgId: string, updates: Partial<User>): Promise<User | undefined>;
  
  // Referral operations
  createReferral(referral: InsertReferral): Promise<Referral>;
  getReferralsByReferrer(tgId: string): Promise<Referral[]>;
  validateReferral(referralId: string): Promise<Referral | undefined>;
  
  // LP Transaction operations
  createLpTransaction(transaction: InsertLpTransaction): Promise<LpTransaction>;
  getLpTransactionsByUser(tgId: string): Promise<LpTransaction[]>;
  
  // Download operations
  createDownload(download: InsertDownload): Promise<Download>;
  getDownloadsByUser(tgId: string, limit?: number): Promise<Download[]>;
  
  // Utility operations
  generateRefCode(): string;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByTgId(tgId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.tgId, tgId));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const refCode = this.generateRefCode();
    const [user] = await db
      .insert(users)
      .values({ ...insertUser, refCode })
      .returning();
    
    // Create initial LP bonus transaction
    await this.createLpTransaction({
      tgId: user.tgId,
      delta: 10.0,
      reason: "init_bonus",
      metaJson: { description: "Initial LP bonus for new user" }
    });
    
    return user;
  }

  async updateUser(tgId: string, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.tgId, tgId))
      .returning();
    return user || undefined;
  }

  async createReferral(insertReferral: InsertReferral): Promise<Referral> {
    const [referral] = await db
      .insert(referrals)
      .values(insertReferral)
      .returning();
    return referral;
  }

  async getReferralsByReferrer(tgId: string): Promise<Referral[]> {
    return await db
      .select()
      .from(referrals)
      .where(eq(referrals.referrerTgId, tgId))
      .orderBy(desc(referrals.createdAt));
  }

  async validateReferral(referralId: string): Promise<Referral | undefined> {
    const [referral] = await db
      .update(referrals)
      .set({ 
        status: "validated",
        validatedAt: new Date()
      })
      .where(eq(referrals.id, referralId))
      .returning();
    
    if (referral) {
      // Award LP bonus to referrer
      await this.createLpTransaction({
        tgId: referral.referrerTgId,
        delta: 0.5,
        reason: "referral_bonus",
        metaJson: { referralId: referral.id, refereeTgId: referral.refereeTgId }
      });
      
      // Update referrer's LP balance
      const referrer = await this.getUserByTgId(referral.referrerTgId);
      if (referrer) {
        await this.updateUser(referrer.tgId, { 
          lpBalance: referrer.lpBalance + 0.5 
        });
      }
    }
    
    return referral || undefined;
  }

  async createLpTransaction(insertTransaction: InsertLpTransaction): Promise<LpTransaction> {
    const [transaction] = await db
      .insert(lpTransactions)
      .values(insertTransaction)
      .returning();
    return transaction;
  }

  async getLpTransactionsByUser(tgId: string): Promise<LpTransaction[]> {
    return await db
      .select()
      .from(lpTransactions)
      .where(eq(lpTransactions.tgId, tgId))
      .orderBy(desc(lpTransactions.createdAt));
  }

  async createDownload(insertDownload: InsertDownload): Promise<Download> {
    const [download] = await db
      .insert(downloads)
      .values(insertDownload)
      .returning();
    
    // If it's a video download, create LP transaction and update user balance
    if (insertDownload.lpCost > 0) {
      await this.createLpTransaction({
        tgId: insertDownload.tgId,
        delta: -insertDownload.lpCost,
        reason: "video_purchase",
        metaJson: { downloadId: download.id, title: download.title }
      });
      
      const user = await this.getUserByTgId(insertDownload.tgId);
      if (user) {
        await this.updateUser(user.tgId, { 
          lpBalance: user.lpBalance - insertDownload.lpCost 
        });
      }
    }
    
    return download;
  }

  async getDownloadsByUser(tgId: string, limit: number = 5): Promise<Download[]> {
    return await db
      .select()
      .from(downloads)
      .where(eq(downloads.tgId, tgId))
      .orderBy(desc(downloads.createdAt))
      .limit(limit);
  }

  generateRefCode(): string {
    return randomUUID().replace(/-/g, '').substring(0, 8).toUpperCase();
  }
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private referrals: Map<string, Referral>;
  private lpTransactions: Map<string, LpTransaction>;
  private downloads: Map<string, Download>;

  constructor() {
    this.users = new Map();
    this.referrals = new Map();
    this.lpTransactions = new Map();
    this.downloads = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByTgId(tgId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.tgId === tgId);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const refCode = this.generateRefCode();
    const user: User = { 
      ...insertUser, 
      id, 
      refCode,
      lpBalance: 10.0,
      isSubscribed: false,
      createdAt: new Date()
    };
    this.users.set(id, user);
    
    // Create initial LP transaction
    await this.createLpTransaction({
      tgId: user.tgId,
      delta: 10.0,
      reason: "init_bonus",
      metaJson: { description: "Initial LP bonus for new user" }
    });
    
    return user;
  }

  async updateUser(tgId: string, updates: Partial<User>): Promise<User | undefined> {
    const user = await this.getUserByTgId(tgId);
    if (user) {
      const updatedUser = { ...user, ...updates };
      this.users.set(user.id, updatedUser);
      return updatedUser;
    }
    return undefined;
  }

  async createReferral(insertReferral: InsertReferral): Promise<Referral> {
    const id = randomUUID();
    const referral: Referral = {
      ...insertReferral,
      id,
      status: "pending",
      createdAt: new Date(),
      validatedAt: null
    };
    this.referrals.set(id, referral);
    return referral;
  }

  async getReferralsByReferrer(tgId: string): Promise<Referral[]> {
    return Array.from(this.referrals.values())
      .filter(ref => ref.referrerTgId === tgId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async validateReferral(referralId: string): Promise<Referral | undefined> {
    const referral = this.referrals.get(referralId);
    if (referral) {
      referral.status = "validated";
      referral.validatedAt = new Date();
      
      // Award LP bonus
      await this.createLpTransaction({
        tgId: referral.referrerTgId,
        delta: 0.5,
        reason: "referral_bonus",
        metaJson: { referralId, refereeTgId: referral.refereeTgId }
      });
      
      const referrer = await this.getUserByTgId(referral.referrerTgId);
      if (referrer) {
        await this.updateUser(referrer.tgId, { 
          lpBalance: referrer.lpBalance + 0.5 
        });
      }
    }
    return referral;
  }

  async createLpTransaction(insertTransaction: InsertLpTransaction): Promise<LpTransaction> {
    const id = randomUUID();
    const transaction: LpTransaction = {
      ...insertTransaction,
      id,
      createdAt: new Date()
    };
    this.lpTransactions.set(id, transaction);
    return transaction;
  }

  async getLpTransactionsByUser(tgId: string): Promise<LpTransaction[]> {
    return Array.from(this.lpTransactions.values())
      .filter(tx => tx.tgId === tgId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createDownload(insertDownload: InsertDownload): Promise<Download> {
    const id = randomUUID();
    const download: Download = {
      ...insertDownload,
      id,
      createdAt: new Date()
    };
    this.downloads.set(id, download);
    
    if (insertDownload.lpCost > 0) {
      await this.createLpTransaction({
        tgId: insertDownload.tgId,
        delta: -insertDownload.lpCost,
        reason: "video_purchase",
        metaJson: { downloadId: id, title: download.title }
      });
      
      const user = await this.getUserByTgId(insertDownload.tgId);
      if (user) {
        await this.updateUser(user.tgId, { 
          lpBalance: user.lpBalance - insertDownload.lpCost 
        });
      }
    }
    
    return download;
  }

  async getDownloadsByUser(tgId: string, limit: number = 5): Promise<Download[]> {
    return Array.from(this.downloads.values())
      .filter(download => download.tgId === tgId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  generateRefCode(): string {
    return randomUUID().replace(/-/g, '').substring(0, 8).toUpperCase();
  }
}

export const storage = new MemStorage();
