import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertDownloadSchema } from "@shared/schema";
import { z } from "zod";
import { bot, TelegramUpdate } from "./telegram";
import crypto from "crypto";

// Mock Tubidy search results
const generateMockResults = (query: string, type: "music" | "video") => {
  const musicResults = [
    { id: "1", title: "Bad Guy", artist: "Billie Eilish", duration: "3:14", type: "music", price: "Gratuit", lpCost: 0 },
    { id: "2", title: "Blinding Lights", artist: "The Weeknd", duration: "3:22", type: "music", price: "Gratuit", lpCost: 0 },
    { id: "3", title: "Shape of You", artist: "Ed Sheeran", duration: "3:53", type: "music", price: "Gratuit", lpCost: 0 },
    { id: "4", title: "Someone Like You", artist: "Adele", duration: "4:45", type: "music", price: "Gratuit", lpCost: 0 },
  ];

  const videoResults = [
    { id: "5", title: "Avengers: Endgame", artist: "Marvel Studios", duration: "3h 1min", type: "video", price: "2 LP", lpCost: 2 },
    { id: "6", title: "Spider-Man: No Way Home", artist: "Sony Pictures", duration: "2h 28min", type: "video", price: "2 LP", lpCost: 2 },
    { id: "7", title: "Top Gun: Maverick", artist: "Paramount Pictures", duration: "2h 11min", type: "video", price: "2 LP", lpCost: 2 },
    { id: "8", title: "The Batman", artist: "Warner Bros", duration: "2h 56min", type: "video", price: "2 LP", lpCost: 2 },
  ];

  const results = type === "music" ? musicResults : videoResults;
  return results.filter(item => 
    item.title.toLowerCase().includes(query.toLowerCase()) ||
    item.artist.toLowerCase().includes(query.toLowerCase())
  );
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Webhook endpoint for Telegram bot
  app.post("/telegram/webhook", async (req, res) => {
    try {
      const update: TelegramUpdate = req.body;
      
      // Process different types of updates
      if (update.message) {
        await handleMessage(update);
      } else if (update.callback_query) {
        await handleCallbackQuery(update);
      }
      
      res.status(200).json({ ok: true });
    } catch (error) {
      console.error("Webhook error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Initialize user endpoint
  app.post("/api/webapp/init", async (req, res) => {
    try {
      const { tgId, username, firstName, lastName, refCode } = req.body;
      
      let user = await storage.getUserByTgId(tgId);
      
      if (!user) {
        // Create new user
        const userData = {
          tgId,
          username: username || null,
          firstName: firstName || null,
          lastName: lastName || null,
          referredBy: null as string | null
        };

        // Check if user came from referral
        if (refCode) {
          const referrer = await storage.getUserByTgId(refCode);
          if (referrer) {
            userData.referredBy = referrer.tgId;
            
            // Create referral record
            await storage.createReferral({
              referrerTgId: referrer.tgId,
              refereeTgId: tgId,
              status: "pending"
            });
          }
        }

        user = await storage.createUser(userData);
      }

      res.json({
        user: {
          id: user.id,
          tgId: user.tgId,
          username: user.username,
          firstName: user.firstName,
          lpBalance: user.lpBalance,
          isSubscribed: user.isSubscribed,
          refCode: user.refCode
        }
      });
    } catch (error) {
      console.error("Init error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Search endpoint
  app.get("/api/webapp/search", async (req, res) => {
    try {
      const { query, type } = req.query;
      
      if (!query || !type) {
        return res.status(400).json({ message: "Query and type are required" });
      }

      if (type !== "music" && type !== "video") {
        return res.status(400).json({ message: "Type must be 'music' or 'video'" });
      }

      const results = generateMockResults(query as string, type as "music" | "video");
      
      res.json({ results });
    } catch (error) {
      console.error("Search error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Download endpoint
  app.post("/api/webapp/download", async (req, res) => {
    try {
      const { tgId, resultId, title, artist, duration, type } = req.body;
      
      const user = await storage.getUserByTgId(tgId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const lpCost = type === "video" ? 2 : 0;
      
      // Check LP balance for videos
      if (type === "video" && user.lpBalance < lpCost) {
        return res.status(400).json({ 
          message: "LP insuffisants",
          lpBalance: user.lpBalance,
          required: lpCost
        });
      }

      // Create download record
      const download = await storage.createDownload({
        tgId,
        kind: type,
        title,
        artist: artist || null,
        duration: duration || null,
        sourceUrl: `https://mock-tubidy.com/${resultId}`,
        deliveredVia: "webapp",
        lpCost
      });

      // Get updated user balance
      const updatedUser = await storage.getUserByTgId(tgId);

      res.json({
        success: true,
        download: {
          id: download.id,
          title: download.title,
          type: download.kind,
          lpCost: download.lpCost
        },
        lpBalance: updatedUser?.lpBalance || user.lpBalance,
        downloadUrl: `https://mock-download.com/${download.id}`
      });
    } catch (error) {
      console.error("Download error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Check subscription endpoint
  app.post("/api/webapp/check-subscription", async (req, res) => {
    try {
      const { tgId } = req.body;
      
      // Real subscription check using Telegram Bot API
      let isSubscribed = false;
      try {
        const channelUsername = process.env.TELEGRAM_CHANNEL || "@musicsolde";
        const chatMember = await bot.getChatMember(channelUsername, parseInt(tgId));
        
        isSubscribed = chatMember.ok && 
          chatMember.result && 
          ["member", "administrator", "creator"].includes(chatMember.result.status);
      } catch (error) {
        console.error("Telegram API error:", error);
        // Fallback to mock for development
        isSubscribed = Math.random() > 0.3;
      }
      
      const user = await storage.updateUser(tgId, { isSubscribed });
      
      if (isSubscribed && user?.referredBy) {
        // Validate referral if user is now subscribed
        const referrals = await storage.getReferralsByReferrer(user.referredBy);
        const pendingReferral = referrals.find(ref => 
          ref.refereeTgId === tgId && ref.status === "pending"
        );
        
        if (pendingReferral) {
          await storage.validateReferral(pendingReferral.id);
        }
      }

      res.json({ 
        isSubscribed,
        lpBalance: user?.lpBalance || 10
      });
    } catch (error) {
      console.error("Subscription check error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get referral link endpoint
  app.post("/api/webapp/ref-link", async (req, res) => {
    try {
      const { tgId } = req.body;
      
      const user = await storage.getUserByTgId(tgId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const referralLink = `https://t.me/MusicSolde_Bot?start=${user.refCode}`;
      
      res.json({ referralLink });
    } catch (error) {
      console.error("Referral link error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get download history endpoint
  app.get("/api/webapp/history/:tgId", async (req, res) => {
    try {
      const { tgId } = req.params;
      
      const downloads = await storage.getDownloadsByUser(tgId, 10);
      
      res.json({ downloads });
    } catch (error) {
      console.error("History error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Handle incoming messages from Telegram
async function handleMessage(update: TelegramUpdate) {
  const message = update.message!;
  const userId = message.from.id;
  const chatId = message.chat.id;
  const text = message.text || "";

  try {
    // Handle /start command
    if (text.startsWith("/start")) {
      const refCode = text.split(" ")[1];
      
      // Create or get user
      let user = await storage.getUserByTgId(userId.toString());
      
      if (!user) {
        const userData = {
          tgId: userId.toString(),
          username: message.from.username || null,
          firstName: message.from.first_name,
          lastName: message.from.last_name || null,
          referredBy: null as string | null
        };

        // Handle referral code
        if (refCode) {
          const referrerUser = await storage.getUserByTgId(refCode);
          if (referrerUser) {
            userData.referredBy = referrerUser.tgId;
            
            // Create referral record
            await storage.createReferral({
              referrerTgId: referrerUser.tgId,
              refereeTgId: userId.toString(),
              status: "pending"
            });
          }
        }

        user = await storage.createUser(userData);
      }

      // Send welcome message with OPEN button
      const welcomeText = `👋 Salut ${message.from.first_name}!\n\n🎵 Bienvenue sur Tubidy Free DL\n\n• Musiques: Téléchargement GRATUIT\n• Vidéos: 2 LP par téléchargement\n• Votre solde: ${user.lpBalance} LP\n\n🎁 Parrainez des amis: +0.5 LP par ami\n\nCliquez sur OPEN pour commencer ⬇️`;
      
      await bot.sendMessage(chatId, welcomeText, {
        reply_markup: {
          inline_keyboard: [[
            {
              text: "🚀 OPEN APP",
              web_app: {
                url: process.env.REPLIT_URL || "https://your-app.replit.app"
              }
            }
          ]]
        }
      });
      return;
    }

    // Handle text messages as search queries
    if (text && !text.startsWith("/")) {
      const musicResults = generateMockResults(text, "music");
      const videoResults = generateMockResults(text, "video");
      
      const allResults = [...musicResults, ...videoResults];
      
      if (allResults.length === 0) {
        await bot.sendMessage(chatId, "❌ Aucun résultat trouvé pour \"" + text + "\".\n\nEssayez avec d'autres mots-clés.");
        return;
      }

      let responseText = `🔍 Résultats pour \"${text}\":\n\n`;
      
      allResults.slice(0, 5).forEach((result, index) => {
        const icon = result.type === "music" ? "🎵" : "🎬";
        const price = result.lpCost === 0 ? "GRATUIT" : `${result.lpCost} LP`;
        responseText += `${icon} ${result.title}\n👤 ${result.artist}\n⏱️ ${result.duration} | 💰 ${price}\n\n`;
      });

      responseText += "🚀 Utilisez l'app pour télécharger:";

      await bot.sendMessage(chatId, responseText, {
        reply_markup: {
          inline_keyboard: [[
            {
              text: "📱 Ouvrir l'app",
              web_app: {
                url: process.env.REPLIT_URL || "https://your-app.replit.app"
              }
            }
          ]]
        }
      });
      return;
    }

    // Default response
    await bot.sendMessage(chatId, "🎵 Tapez le nom d'une musique ou vidéo pour rechercher!\n\nOu utilisez /start pour commencer.");
  } catch (error) {
    console.error("Error handling message:", error);
    await bot.sendMessage(chatId, "❌ Une erreur s'est produite. Veuillez réessayer.");
  }
}

// Handle callback queries from inline keyboards
async function handleCallbackQuery(update: TelegramUpdate) {
  const callbackQuery = update.callback_query!;
  const userId = callbackQuery.from.id;
  const data = callbackQuery.data;

  try {
    if (data === "open_app") {
      await bot.answerCallbackQuery(callbackQuery.id, "Ouverture de l'application...");
      return;
    }

    // Handle other callback data as needed
    await bot.answerCallbackQuery(callbackQuery.id);
  } catch (error) {
    console.error("Error handling callback query:", error);
    await bot.answerCallbackQuery(callbackQuery.id, "Erreur", true);
  }
}
