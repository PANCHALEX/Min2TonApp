#!/usr/bin/env tsx

/**
 * Script to set up Telegram webhook
 * Run with: npx tsx server/webhook-setup.ts
 */

import { bot } from "./telegram";

async function setupWebhook() {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  const webhookUrl = process.env.REPLIT_URL || "https://your-app.replit.app";
  
  if (!botToken) {
    console.error("❌ TELEGRAM_BOT_TOKEN not found in environment");
    process.exit(1);
  }

  console.log("🔧 Setting up Telegram webhook...");
  console.log(`📡 Webhook URL: ${webhookUrl}/telegram/webhook`);

  try {
    // Set webhook
    const response = await fetch(`https://api.telegram.org/bot${botToken}/setWebhook`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        url: `${webhookUrl}/telegram/webhook`,
        allowed_updates: ["message", "callback_query"],
        drop_pending_updates: true,
      }),
    });

    const result = await response.json();
    
    if (result.ok) {
      console.log("✅ Webhook configuré avec succès!");
      console.log(`📋 Description: ${result.description}`);
    } else {
      console.error("❌ Erreur lors de la configuration du webhook:");
      console.error(result);
    }

    // Get webhook info
    const infoResponse = await fetch(`https://api.telegram.org/bot${botToken}/getWebhookInfo`);
    const info = await infoResponse.json();
    
    if (info.ok) {
      console.log("\n📊 Informations du webhook:");
      console.log(`URL: ${info.result.url}`);
      console.log(`Pending updates: ${info.result.pending_update_count}`);
      console.log(`Last error date: ${info.result.last_error_date || "Aucune"}`);
      console.log(`Last error message: ${info.result.last_error_message || "Aucune"}`);
    }

  } catch (error) {
    console.error("❌ Erreur:", error);
    process.exit(1);
  }
}

setupWebhook();