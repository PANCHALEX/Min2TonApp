import crypto from "crypto";

export interface TelegramUpdate {
  update_id: number;
  message?: {
    message_id: number;
    from: {
      id: number;
      is_bot: boolean;
      first_name: string;
      last_name?: string;
      username?: string;
      language_code?: string;
    };
    chat: {
      id: number;
      first_name?: string;
      last_name?: string;
      username?: string;
      type: string;
    };
    date: number;
    text?: string;
    entities?: Array<{
      offset: number;
      length: number;
      type: string;
    }>;
  };
  callback_query?: {
    id: string;
    from: {
      id: number;
      is_bot: boolean;
      first_name: string;
      last_name?: string;
      username?: string;
    };
    message?: any;
    data?: string;
  };
}

export class TelegramBot {
  private token: string;
  private baseUrl: string;

  constructor(token: string) {
    this.token = token;
    this.baseUrl = `https://api.telegram.org/bot${token}`;
  }

  async sendMessage(chatId: number, text: string, options?: {
    reply_markup?: any;
    parse_mode?: "HTML" | "Markdown";
  }) {
    try {
      const response = await fetch(`${this.baseUrl}/sendMessage`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          chat_id: chatId,
          text,
          ...options,
        }),
      });
      return await response.json();
    } catch (error) {
      console.error("Error sending message:", error);
      throw error;
    }
  }

  async getChatMember(chatId: string, userId: number) {
    try {
      const response = await fetch(`${this.baseUrl}/getChatMember`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          chat_id: chatId,
          user_id: userId,
        }),
      });
      return await response.json();
    } catch (error) {
      console.error("Error checking chat member:", error);
      throw error;
    }
  }

  async sendDocument(chatId: number, document: string, options?: {
    caption?: string;
    reply_markup?: any;
  }) {
    try {
      const response = await fetch(`${this.baseUrl}/sendDocument`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          chat_id: chatId,
          document,
          ...options,
        }),
      });
      return await response.json();
    } catch (error) {
      console.error("Error sending document:", error);
      throw error;
    }
  }

  async sendAudio(chatId: number, audio: string, options?: {
    caption?: string;
    title?: string;
    performer?: string;
    duration?: number;
    reply_markup?: any;
  }) {
    try {
      const response = await fetch(`${this.baseUrl}/sendAudio`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          chat_id: chatId,
          audio,
          ...options,
        }),
      });
      return await response.json();
    } catch (error) {
      console.error("Error sending audio:", error);
      throw error;
    }
  }

  async answerCallbackQuery(callbackQueryId: string, text?: string, showAlert?: boolean) {
    try {
      const response = await fetch(`${this.baseUrl}/answerCallbackQuery`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          callback_query_id: callbackQueryId,
          text,
          show_alert: showAlert,
        }),
      });
      return await response.json();
    } catch (error) {
      console.error("Error answering callback query:", error);
      throw error;
    }
  }

  verifyWebhookSignature(body: string, signature: string): boolean {
    const secretKey = crypto
      .createHash("sha256")
      .update(this.token)
      .digest();
    
    const hash = crypto
      .createHmac("sha256", secretKey)
      .update(body)
      .digest("hex");
    
    return `sha256=${hash}` === signature;
  }
}

export const bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN || "");