import { sql } from "drizzle-orm";
import { pgTable, text, varchar, boolean, real, timestamp, integer, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tgId: varchar("tg_id").notNull().unique(),
  username: text("username"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  lpBalance: real("lp_balance").notNull().default(10.0),
  isSubscribed: boolean("is_subscribed").notNull().default(false),
  refCode: varchar("ref_code").notNull().unique(),
  referredBy: varchar("referred_by"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const referrals = pgTable("referrals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  referrerTgId: varchar("referrer_tg_id").notNull(),
  refereeTgId: varchar("referee_tg_id").notNull(),
  status: text("status").notNull().default("pending"), // pending | validated | rejected
  createdAt: timestamp("created_at").notNull().defaultNow(),
  validatedAt: timestamp("validated_at"),
});

export const lpTransactions = pgTable("lp_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tgId: varchar("tg_id").notNull(),
  delta: real("delta").notNull(),
  reason: text("reason").notNull(), // init_bonus | video_purchase | referral_bonus | admin_adjust
  metaJson: jsonb("meta_json"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const downloads = pgTable("downloads", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tgId: varchar("tg_id").notNull(),
  kind: text("kind").notNull(), // music | video
  title: text("title").notNull(),
  artist: text("artist"),
  duration: text("duration"),
  sourceUrl: text("source_url"),
  deliveredVia: text("delivered_via").notNull(), // bot | webapp
  lpCost: real("lp_cost").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const usersRelations = relations(users, ({ many }) => ({
  downloads: many(downloads),
  lpTransactions: many(lpTransactions),
  referralsGiven: many(referrals, { relationName: "referrer" }),
  referralsReceived: many(referrals, { relationName: "referee" }),
}));

export const referralsRelations = relations(referrals, ({ one }) => ({
  referrer: one(users, {
    fields: [referrals.referrerTgId],
    references: [users.tgId],
    relationName: "referrer",
  }),
  referee: one(users, {
    fields: [referrals.refereeTgId],
    references: [users.tgId],
    relationName: "referee",
  }),
}));

export const downloadsRelations = relations(downloads, ({ one }) => ({
  user: one(users, {
    fields: [downloads.tgId],
    references: [users.tgId],
  }),
}));

export const lpTransactionsRelations = relations(lpTransactions, ({ one }) => ({
  user: one(users, {
    fields: [lpTransactions.tgId],
    references: [users.tgId],
  }),
}));

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  refCode: true,
});

export const insertReferralSchema = createInsertSchema(referrals).omit({
  id: true,
  createdAt: true,
  validatedAt: true,
});

export const insertLpTransactionSchema = createInsertSchema(lpTransactions).omit({
  id: true,
  createdAt: true,
});

export const insertDownloadSchema = createInsertSchema(downloads).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertReferral = z.infer<typeof insertReferralSchema>;
export type Referral = typeof referrals.$inferSelect;
export type InsertLpTransaction = z.infer<typeof insertLpTransactionSchema>;
export type LpTransaction = typeof lpTransactions.$inferSelect;
export type InsertDownload = z.infer<typeof insertDownloadSchema>;
export type Download = typeof downloads.$inferSelect;
