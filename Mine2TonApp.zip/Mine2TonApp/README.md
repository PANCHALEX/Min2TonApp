# Mon Miner App

Une mini application de mining TonCoin développée en TypeScript et déployée sur Render.

## Description
Cette application permet aux utilisateurs de miner des TonCoins via une interface web simple.  
Elle inclut un dashboard, un système de cooldown, un leaderboard et des liens de parrainage.

## Fonctionnalités
- Dashboard utilisateur pour suivre le mining
- Cooldown système pour limiter les actions
- Leaderboard des meilleurs joueurs
- Génération de liens de parrainage

## Prérequis
- Node.js v18+  
- NPM ou Yarn  
- TypeScript

## Installation locale
1. Cloner le repo :  
```bash
git clone https://github.com/TON_USERNAME/mon-miner-app.git