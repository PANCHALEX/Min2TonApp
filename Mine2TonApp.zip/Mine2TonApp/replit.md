# Mine2Ton - Telegram Web App Mining Game

## Overview

Mine2Ton is a gamified cryptocurrency mining application built as a Telegram Web App. Users interact with a virtual roulette wheel to "mine" LP tokens that can be converted to TON cryptocurrency. The application features a referral system, power machine upgrades, channel subscription requirements, and real-time mining mechanics through WebSocket connections.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Radix UI components with shadcn/ui styling system
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query for server state, React hooks for local state
- **Routing**: Wouter for lightweight client-side routing
- **Real-time Communication**: WebSocket connection for live mining updates

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Database Integration**: Drizzle ORM with PostgreSQL dialect
- **Session Management**: Memory-based storage with IStorage interface abstraction
- **WebSocket Server**: ws library for real-time mining updates
- **API Design**: RESTful endpoints with TypeScript validation using Zod

### Data Storage Solutions
- **Primary Database**: PostgreSQL with Neon serverless database
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Centralized schema definitions in shared directory
- **Development Storage**: In-memory storage implementation for testing
- **Connection Management**: Connection pooling through @neondatabase/serverless

### Authentication and Authorization
- **Telegram Integration**: Telegram Web App authentication using initData validation
- **Session Handling**: Telegram user ID-based session management
- **Channel Verification**: Telegram Bot API integration for subscription verification
- **User Management**: Automatic user creation on first Telegram app access

### External Service Integrations
- **Telegram Bot API**: Channel subscription verification and user messaging
- **TON Blockchain**: Payment verification and withdrawal processing (simulated)
- **WebSocket Infrastructure**: Real-time mining updates and user synchronization
- **Replit Integration**: Development environment optimizations and runtime error handling

### Key Design Patterns
- **Layered Architecture**: Clear separation between client, server, and shared code
- **Interface Segregation**: IStorage interface allows switching between memory and database storage
- **Real-time Updates**: WebSocket-based architecture for immediate user feedback
- **Type Safety**: End-to-end TypeScript with shared schema validation
- **Component Composition**: Modular React components with shadcn/ui design system
- **Service-Oriented Design**: Separate service classes for Telegram, TON, and channel verification

### Mining Mechanics
- **Virtual Mining**: Roulette wheel interaction generates LP tokens based on user's mining power
- **Power Upgrades**: Users can purchase power machines to increase mining efficiency
- **Speed Acceleration**: Temporary speed boosts available through TON payments
- **Daily Tracking**: Mining progress and earnings tracked with daily reset mechanics

### Monetization Features
- **TON Integration**: Users can purchase upgrades and acceleration with TON cryptocurrency
- **Withdrawal System**: LP tokens can be converted and withdrawn as TON
- **Referral Program**: Users earn bonuses for successful referrals
- **Channel Requirements**: Mining features locked behind Telegram channel subscription