interface TelegramWebApp {
  ready(): void;
  close(): void;
  expand(): void;
  MainButton: {
    text: string;
    color: string;
    textColor: string;
    isVisible: boolean;
    isProgressVisible: boolean;
    isActive: boolean;
    setText(text: string): void;
    onClick(fn: () => void): void;
    show(): void;
    hide(): void;
  };
  initData: string;
  initDataUnsafe: {
    user?: {
      id: number;
      first_name: string;
      last_name?: string;
      username?: string;
      language_code?: string;
    };
    auth_date: number;
    hash: string;
    [key: string]: any;
  };
  colorScheme: 'light' | 'dark';
  themeParams: {
    bg_color?: string;
    text_color?: string;
    hint_color?: string;
    link_color?: string;
    button_color?: string;
    button_text_color?: string;
  };
  isExpanded: boolean;
  viewportHeight: number;
  viewportStableHeight: number;
  headerColor: string;
  backgroundColor: string;
  isClosingConfirmationEnabled: boolean;
  platform: string;
  version: string;
}

declare global {
  interface Window {
    Telegram?: {
      WebApp: TelegramWebApp;
    };
  }
}

export class TelegramWebAppSDK {
  static isAvailable(): boolean {
    return typeof window !== 'undefined' && !!window.Telegram?.WebApp;
  }

  static getWebApp(): TelegramWebApp | null {
    return window.Telegram?.WebApp || null;
  }

  static initialize(): TelegramWebApp | null {
    const webApp = this.getWebApp();
    if (webApp) {
      webApp.ready();
      webApp.expand();
      
      // Apply theme
      if (webApp.colorScheme === 'dark') {
        document.documentElement.classList.add('dark');
      }
    }
    return webApp;
  }

  static getUser() {
    const webApp = this.getWebApp();
    return webApp?.initDataUnsafe?.user || null;
  }

  static getInitData(): string {
    const webApp = this.getWebApp();
    return webApp?.initData || '';
  }

  static showMainButton(text: string, onClick: () => void) {
    const webApp = this.getWebApp();
    if (webApp?.MainButton) {
      webApp.MainButton.setText(text);
      webApp.MainButton.onClick(onClick);
      webApp.MainButton.show();
    }
  }

  static hideMainButton() {
    const webApp = this.getWebApp();
    if (webApp?.MainButton) {
      webApp.MainButton.hide();
    }
  }

  static close() {
    const webApp = this.getWebApp();
    if (webApp) {
      webApp.close();
    }
  }

  static openTelegramLink(url: string) {
    const webApp = this.getWebApp();
    if (webApp) {
      // Use Telegram's built-in method if available
      window.open(url, '_blank');
    } else {
      window.open(url, '_blank');
    }
  }

  static openInvoice(url: string) {
    const webApp = this.getWebApp();
    if (webApp) {
      window.open(url, '_blank');
    }
  }

  static hapticFeedback(type: 'impactOccurred' | 'notificationOccurred' | 'selectionChanged') {
    const webApp = this.getWebApp();
    if (webApp && (webApp as any).HapticFeedback) {
      try {
        switch (type) {
          case 'impactOccurred':
            (webApp as any).HapticFeedback.impactOccurred('medium');
            break;
          case 'notificationOccurred':
            (webApp as any).HapticFeedback.notificationOccurred('success');
            break;
          case 'selectionChanged':
            (webApp as any).HapticFeedback.selectionChanged();
            break;
        }
      } catch (error) {
        console.warn('Haptic feedback not available:', error);
      }
    }
  }
}
