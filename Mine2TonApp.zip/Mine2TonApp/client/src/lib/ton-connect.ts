export interface TonConnectWallet {
  device: {
    appName: string;
    appVersion: string;
    maxProtocolVersion: number;
    platform: string;
  };
  provider: string;
  account: {
    address: string;
    chain: string;
    walletStateInit: string;
    publicKey?: string;
  };
}

export interface TonConnectTransaction {
  messages: Array<{
    address: string;
    amount: string;
    payload?: string;
    stateInit?: string;
  }>;
  validUntil?: number;
  network?: string;
}

export class TonConnectSDK {
  private static instance: TonConnectSDK;
  private tonConnectUI: any = null;

  constructor() {
    this.initializeTonConnect();
  }

  static getInstance(): TonConnectSDK {
    if (!TonConnectSDK.instance) {
      TonConnectSDK.instance = new TonConnectSDK();
    }
    return TonConnectSDK.instance;
  }

  private async initializeTonConnect() {
    try {
      // Check if TON Connect UI is available
      if (typeof window !== 'undefined') {
        // Load TON Connect UI script if not already loaded
        if (!(window as any).TonConnectUI) {
          await this.loadTonConnectScript();
        }
        
        if ((window as any).TonConnectUI) {
          this.tonConnectUI = new (window as any).TonConnectUI({
            manifestUrl: `${window.location.origin}/tonconnect-manifest.json`,
            buttonRootId: null // We'll handle connection manually
          });
        }
      }
    } catch (error) {
      console.error('Failed to initialize TON Connect:', error);
    }
  }

  private async loadTonConnectScript(): Promise<void> {
    return new Promise((resolve, reject) => {
      if ((window as any).TonConnectUI) {
        resolve();
        return;
      }

      const script = document.createElement('script');
      script.src = 'https://unpkg.com/@tonconnect/ui@latest/dist/tonconnect-ui.min.js';
      script.onload = () => resolve();
      script.onerror = () => reject(new Error('Failed to load TON Connect script'));
      document.head.appendChild(script);
    });
  }

  async connectWallet(): Promise<TonConnectWallet | null> {
    try {
      if (!this.tonConnectUI) {
        await this.initializeTonConnect();
      }

      if (this.tonConnectUI) {
        const wallet = await this.tonConnectUI.connectWallet();
        return wallet;
      }

      // Fallback: open wallet selection page
      const walletUrl = 'https://ton.org/wallets';
      window.open(walletUrl, '_blank');
      return null;
    } catch (error) {
      console.error('Wallet connection error:', error);
      throw error;
    }
  }

  async disconnectWallet(): Promise<void> {
    try {
      if (this.tonConnectUI) {
        await this.tonConnectUI.disconnect();
      }
    } catch (error) {
      console.error('Wallet disconnection error:', error);
      throw error;
    }
  }

  async sendTransaction(transaction: TonConnectTransaction): Promise<any> {
    try {
      if (!this.tonConnectUI) {
        throw new Error('TON Connect not initialized');
      }

      const result = await this.tonConnectUI.sendTransaction(transaction);
      return result;
    } catch (error) {
      console.error('Transaction error:', error);
      throw error;
    }
  }

  getConnectedWallet(): TonConnectWallet | null {
    try {
      if (this.tonConnectUI) {
        return this.tonConnectUI.wallet;
      }
      return null;
    } catch (error) {
      console.error('Get wallet error:', error);
      return null;
    }
  }

  isConnected(): boolean {
    try {
      return !!(this.tonConnectUI && this.tonConnectUI.connected);
    } catch (error) {
      return false;
    }
  }

  onStatusChange(callback: (wallet: TonConnectWallet | null) => void) {
    try {
      if (this.tonConnectUI) {
        this.tonConnectUI.onStatusChange(callback);
      }
    } catch (error) {
      console.error('Status change listener error:', error);
    }
  }

  static formatNanoTON(nanoTON: string | number): string {
    const nano = typeof nanoTON === 'string' ? parseInt(nanoTON) : nanoTON;
    return (nano / 1000000000).toFixed(9);
  }

  static parseToNanoTON(ton: string | number): string {
    const tonAmount = typeof ton === 'string' ? parseFloat(ton) : ton;
    return Math.floor(tonAmount * 1000000000).toString();
  }

  static createPaymentUrl(address: string, amount: string, comment?: string): string {
    const nanoAmount = this.parseToNanoTON(amount);
    let url = `ton://transfer/${address}?amount=${nanoAmount}`;
    
    if (comment) {
      url += `&text=${encodeURIComponent(comment)}`;
    }
    
    return url;
  }
}

// Export singleton instance
export const tonConnect = TonConnectSDK.getInstance();
