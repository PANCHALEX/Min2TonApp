import { useState, useEffect } from 'react';

interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  allows_write_to_pm?: boolean;
}

interface TelegramWebApp {
  ready: () => void;
  close: () => void;
  expand: () => void;
  MainButton: {
    text: string;
    color: string;
    textColor: string;
    isVisible: boolean;
    isProgressVisible: boolean;
    isActive: boolean;
    setText: (text: string) => void;
    onClick: (fn: () => void) => void;
    show: () => void;
    hide: () => void;
  };
  initData: string;
  initDataUnsafe: {
    user?: TelegramUser;
    auth_date: number;
    hash: string;
    [key: string]: any;
  };
  colorScheme: 'light' | 'dark';
  themeParams: {
    bg_color?: string;
    text_color?: string;
    hint_color?: string;
    link_color?: string;
    button_color?: string;
    button_text_color?: string;
  };
  isExpanded: boolean;
  viewportHeight: number;
  viewportStableHeight: number;
  headerColor: string;
  backgroundColor: string;
  isClosingConfirmationEnabled: boolean;
  platform: string;
  version: string;
}

declare global {
  interface Window {
    Telegram?: {
      WebApp: TelegramWebApp;
    };
  }
}

export function useTelegram() {
  const [isReady, setIsReady] = useState(false);
  const [user, setUser] = useState<TelegramUser | null>(null);
  const [initData, setInitData] = useState<string>('');

  useEffect(() => {
    const initializeTelegram = () => {
      if (window.Telegram?.WebApp) {
        const webApp = window.Telegram.WebApp;
        
        // Initialize the app
        webApp.ready();
        webApp.expand();
        
        // Set theme
        if (webApp.colorScheme === 'dark') {
          document.documentElement.classList.add('dark');
        }
        
        // Get user data
        if (webApp.initDataUnsafe.user) {
          setUser(webApp.initDataUnsafe.user);
        }
        
        setInitData(webApp.initData);
        setIsReady(true);
        
        console.log('Telegram WebApp initialized:', {
          user: webApp.initDataUnsafe.user,
          platform: webApp.platform,
          version: webApp.version
        });
      } else {
        // Fallback for development/testing
        console.warn('Telegram WebApp not available. Running in development mode.');
        
        // Create mock user for development
        const mockUser: TelegramUser = {
          id: 123456789,
          first_name: 'Test',
          last_name: 'User',
          username: 'testuser',
          language_code: 'en'
        };
        
        setUser(mockUser);
        setIsReady(true);
      }
    };

    // Try to initialize immediately
    initializeTelegram();

    // Also try after a short delay in case the script is still loading
    const timer = setTimeout(initializeTelegram, 100);

    return () => clearTimeout(timer);
  }, []);

  const showMainButton = (text: string, onClick: () => void) => {
    if (window.Telegram?.WebApp?.MainButton) {
      const mainButton = window.Telegram.WebApp.MainButton;
      mainButton.setText(text);
      mainButton.onClick(onClick);
      mainButton.show();
    }
  };

  const hideMainButton = () => {
    if (window.Telegram?.WebApp?.MainButton) {
      window.Telegram.WebApp.MainButton.hide();
    }
  };

  const close = () => {
    if (window.Telegram?.WebApp) {
      window.Telegram.WebApp.close();
    }
  };

  return {
    isReady,
    user,
    initData,
    showMainButton,
    hideMainButton,
    close,
    webApp: window.Telegram?.WebApp,
  };
}
