import { useState, useEffect, useCallback, useRef } from 'react';
import { useToast } from '@/hooks/use-toast';

interface MiningData {
  totalLP: string;
  tonBalance: string;
  totalSpins: number;
  dailyEarnings: string;
  miningPower: number;
  wheelSpeed: number;
}

export function useMining() {
  const [isConnected, setIsConnected] = useState(false);
  const [miningData, setMiningData] = useState<MiningData | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const { toast } = useToast();

  const connectWebSocket = useCallback((telegramId: string) => {
    try {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log('WebSocket connected');
        setIsConnected(true);
        
        // Authenticate with Telegram ID
        ws.send(JSON.stringify({
          type: 'authenticate',
          telegramId: telegramId
        }));
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          console.log('WebSocket message:', data);
          
          switch (data.type) {
            case 'mining_update':
              setMiningData({
                totalLP: data.totalLP,
                tonBalance: data.tonBalance,
                totalSpins: data.totalSpins,
                dailyEarnings: data.dailyEarnings,
                miningPower: data.miningPower || 10000,
                wheelSpeed: data.wheelSpeed || 1,
              });
              
              if (data.reward && parseFloat(data.reward) > 0) {
                toast({
                  title: "Mining Successful!",
                  description: `+${data.reward} LP earned`,
                  className: "bg-secondary text-secondary-foreground",
                });
              }
              break;
              
            case 'subscription_required':
              toast({
                title: "Subscription Required",
                description: data.message,
                variant: "destructive",
              });
              break;
              
            case 'error':
              toast({
                title: "Mining Error",
                description: data.message,
                variant: "destructive",
              });
              break;
          }
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };

      ws.onclose = () => {
        console.log('WebSocket disconnected');
        setIsConnected(false);
        
        // Attempt to reconnect after 5 seconds
        setTimeout(() => {
          if (wsRef.current?.readyState === WebSocket.CLOSED) {
            connectWebSocket(telegramId);
          }
        }, 5000);
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        setIsConnected(false);
      };

    } catch (error) {
      console.error('WebSocket connection error:', error);
      setIsConnected(false);
    }
  }, [toast]);

  const sendMiningAction = useCallback(() => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'mine'
      }));
    } else {
      toast({
        title: "Connection Error",
        description: "Not connected to mining server",
        variant: "destructive",
      });
    }
  }, [toast]);

  useEffect(() => {
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  return {
    isConnected,
    miningData,
    connectWebSocket,
    sendMiningAction,
  };
}
