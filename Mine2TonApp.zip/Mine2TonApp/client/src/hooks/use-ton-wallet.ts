import { useState, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';

interface TonWalletState {
  connected: boolean;
  address: string | null;
  balance: string | null;
}

export function useTonWallet() {
  const [walletState, setWalletState] = useState<TonWalletState>({
    connected: false,
    address: null,
    balance: null,
  });
  
  const { toast } = useToast();

  const connect = useCallback(async () => {
    try {
      // Check if TON Connect is available
      if (typeof window !== 'undefined' && (window as any).tonConnectUI) {
        const tonConnectUI = (window as any).tonConnectUI;
        
        const connectedWallet = await tonConnectUI.connectWallet();
        
        if (connectedWallet) {
          setWalletState({
            connected: true,
            address: connectedWallet.account.address,
            balance: null, // Would fetch balance in real implementation
          });
          
          toast({
            title: "Wallet Connected",
            description: `Connected to ${connectedWallet.device.appName}`,
          });
          
          return true;
        }
      } else {
        // Fallback for browsers without TON Connect
        toast({
          title: "TON Wallet Required",
          description: "Please install a TON wallet to make payments",
          variant: "destructive",
        });
        
        // Open wallet selection
        const walletUrl = "https://ton.org/wallets";
        window.open(walletUrl, '_blank');
      }
      
      return false;
    } catch (error) {
      console.error('Wallet connection error:', error);
      toast({
        title: "Connection Failed",
        description: "Failed to connect to TON wallet",
        variant: "destructive",
      });
      return false;
    }
  }, [toast]);

  const disconnect = useCallback(async () => {
    try {
      if (typeof window !== 'undefined' && (window as any).tonConnectUI) {
        const tonConnectUI = (window as any).tonConnectUI;
        await tonConnectUI.disconnect();
      }
      
      setWalletState({
        connected: false,
        address: null,
        balance: null,
      });
      
      toast({
        title: "Wallet Disconnected",
        description: "TON wallet has been disconnected",
      });
    } catch (error) {
      console.error('Wallet disconnection error:', error);
    }
  }, [toast]);

  const sendTransaction = useCallback(async (transaction: {
    to: string;
    value: string;
    data?: string;
  }) => {
    try {
      if (!walletState.connected) {
        throw new Error('Wallet not connected');
      }
      
      if (typeof window !== 'undefined' && (window as any).tonConnectUI) {
        const tonConnectUI = (window as any).tonConnectUI;
        
        const result = await tonConnectUI.sendTransaction({
          messages: [
            {
              address: transaction.to,
              amount: transaction.value,
              payload: transaction.data,
            }
          ]
        });
        
        return result;
      }
      
      throw new Error('TON Connect not available');
    } catch (error) {
      console.error('Transaction error:', error);
      toast({
        title: "Transaction Failed",
        description: "Failed to send TON transaction",
        variant: "destructive",
      });
      throw error;
    }
  }, [walletState.connected, toast]);

  return {
    ...walletState,
    connect,
    disconnect,
    sendTransaction,
  };
}
