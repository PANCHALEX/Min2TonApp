import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { useTelegram } from "@/hooks/use-telegram";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Star, X } from "lucide-react";

export function ChannelSubscription() {
  const [isVisible, setIsVisible] = useState(false);
  const [countdown, setCountdown] = useState(5);
  const { user } = useTelegram();

  const checkSubscriptionMutation = useMutation({
    mutationFn: async (telegramId: string) => {
      const response = await apiRequest("POST", "/api/check-subscription", { telegramId });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.isSubscribed) {
        setIsVisible(false);
      }
    },
  });

  useEffect(() => {
    if (!user) return;

    // Show subscription prompt after 5 seconds if not subscribed
    const timer = setTimeout(() => {
      if (!user.isChannelSubscribed) {
        setIsVisible(true);
      }
    }, 5000);

    return () => clearTimeout(timer);
  }, [user]);

  useEffect(() => {
    if (isVisible && countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [isVisible, countdown]);

  const handleJoinChannel = () => {
    // Open Telegram channel
    window.open('https://t.me/mine2tonchannel', '_blank');
    
    // Start checking subscription status
    setTimeout(() => {
      if (user) {
        checkSubscriptionMutation.mutate(user.telegramId);
      }
    }, 3000);
  };

  const handleDismiss = () => {
    setIsVisible(false);
  };

  if (!isVisible || user?.isChannelSubscribed) {
    return null;
  }

  return (
    <Card className="bg-gradient-to-r from-primary to-secondary mx-4 mt-4" data-testid="subscription-prompt">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3 flex-1">
            <Star className="text-accent" />
            <div className="flex-1">
              <p className="font-semibold text-sm text-background">Join our channel to mine!</p>
              <p className="text-xs opacity-90 text-background">
                Subscribe to @mine2tonchannel to unlock your wheel
              </p>
              {countdown > 0 && (
                <p className="text-xs opacity-75 text-background mt-1">
                  Mining unlocks in {countdown}s after subscription
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button 
              className="bg-accent text-accent-foreground px-3 py-1 rounded-md text-sm font-medium"
              onClick={handleJoinChannel}
              data-testid="button-join-channel"
            >
              Join
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDismiss}
              className="text-background hover:bg-background/10"
              data-testid="button-dismiss-subscription"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
