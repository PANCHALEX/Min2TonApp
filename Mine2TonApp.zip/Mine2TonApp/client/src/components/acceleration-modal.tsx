import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useTelegram } from "@/hooks/use-telegram";
import { useTonWallet } from "@/hooks/use-ton-wallet";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Bolt, Gauge } from "lucide-react";

interface AccelerationTier {
  multiplier: number;
  price: string;
  description: string;
}

const accelerationTiers: AccelerationTier[] = [
  {
    multiplier: 2,
    price: "5",
    description: "Double mining rate"
  },
  {
    multiplier: 5,
    price: "12",
    description: "5x faster mining"
  },
  {
    multiplier: 10,
    price: "25",
    description: "Maximum velocity"
  }
];

export function AccelerationModal() {
  const [isOpen, setIsOpen] = useState(false);
  const { user } = useTelegram();
  const { connect, connected } = useTonWallet();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const purchaseAccelerationMutation = useMutation({
    mutationFn: async (data: { userId: string; speedMultiplier: number; price: string; tonTxHash: string }) => {
      const response = await apiRequest("POST", "/api/purchase-acceleration", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Acceleration Purchased!",
        description: "Your wheel speed has been permanently upgraded.",
      });
      setIsOpen(false);
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
    },
    onError: (error: any) => {
      toast({
        title: "Purchase Failed",
        description: error.message || "Failed to purchase acceleration",
        variant: "destructive",
      });
    },
  });

  const handlePurchase = async (tier: AccelerationTier) => {
    if (!connected) {
      await connect();
      return;
    }

    if (!user) return;

    try {
      // Create payment request
      const paymentUrl = `ton://transfer/UQYour-Wallet-Address-Here?amount=${parseFloat(tier.price) * 1000000000}&text=${encodeURIComponent(`${tier.multiplier}x Speed Boost`)}`;
      
      // Open TON wallet for payment
      window.open(paymentUrl, '_blank');
      
      toast({
        title: "Payment Initiated",
        description: `Please complete the payment of ${tier.price} TON in your wallet`,
      });

      // In a real implementation, you would wait for the transaction confirmation
      // For demo purposes, we'll simulate it
      setTimeout(() => {
        const mockTxHash = `accel_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        purchaseAccelerationMutation.mutate({
          userId: user.id,
          speedMultiplier: tier.multiplier,
          price: tier.price,
          tonTxHash: mockTxHash,
        });
      }, 3000);
    } catch (error) {
      console.error('Purchase error:', error);
      toast({
        title: "Purchase Failed",
        description: "Failed to initiate payment. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          className="bg-primary text-primary-foreground py-3 px-4 rounded-lg font-semibold flex items-center justify-center space-x-2 hover:opacity-90 transition-opacity"
          data-testid="button-open-acceleration"
        >
          <Bolt className="h-4 w-4" />
          <span>Upgrades</span>
        </Button>
      </DialogTrigger>
      
      <DialogContent className="bg-card border-border max-w-md mx-auto">
        <DialogHeader>
          <DialogTitle>Wheel Acceleration</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <Card className="bg-gradient-to-r from-primary/20 to-secondary/20 border-primary/30">
            <CardContent className="p-4">
              <div className="text-center">
                <Gauge className="text-primary text-2xl mb-2 mx-auto" />
                <h3 className="font-semibold">Speed Boost</h3>
                <p className="text-sm text-muted-foreground">Permanently increase your wheel speed</p>
              </div>
            </CardContent>
          </Card>
          
          <div className="space-y-3">
            {accelerationTiers.map((tier) => {
              const isCurrentSpeed = (user?.wheelSpeed || 1) >= tier.multiplier;
              
              return (
                <Card key={tier.multiplier} className="bg-muted border-border">
                  <CardContent className="p-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium" data-testid={`text-speed-${tier.multiplier}x`}>
                          {tier.multiplier}x Speed
                        </p>
                        <p className="text-xs text-muted-foreground">{tier.description}</p>
                        {isCurrentSpeed && (
                          <p className="text-xs text-secondary font-medium">✓ Owned</p>
                        )}
                      </div>
                      <div className="text-right">
                        <p className="ton-gradient text-transparent bg-clip-text font-bold" data-testid={`text-price-${tier.multiplier}x`}>
                          {tier.price} TON
                        </p>
                        <Button 
                          className="bg-primary text-primary-foreground px-3 py-1 rounded-md text-sm mt-1"
                          onClick={() => handlePurchase(tier)}
                          disabled={isCurrentSpeed || purchaseAccelerationMutation.isPending}
                          data-testid={`button-buy-${tier.multiplier}x-speed`}
                        >
                          {isCurrentSpeed ? 'Owned' : 'Buy'}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
