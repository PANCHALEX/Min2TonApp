import { useQuery } from "@tanstack/react-query";
import { useTonWallet } from "@/hooks/use-ton-wallet";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Microchip, Server, Rocket, Settings } from "lucide-react";

interface PowerMachine {
  id: string;
  name: string;
  power: number;
  price: string;
  description: string;
}

const machineIcons = {
  "basic-miner": Microchip,
  "pro-miner": Server,
  "ultra-miner": Rocket,
};

const machineColors = {
  "basic-miner": "primary",
  "pro-miner": "secondary", 
  "ultra-miner": "accent",
};

export function PowerMachines() {
  const { connect, connected, sendTransaction } = useTonWallet();
  const { toast } = useToast();

  const { data: machinesData } = useQuery({
    queryKey: ['/api/power-machines'],
  });

  const machines = machinesData?.machines || [];

  const handlePurchase = async (machine: PowerMachine) => {
    if (!connected) {
      await connect();
      return;
    }

    try {
      // Create payment request
      const paymentUrl = `ton://transfer/UQYour-Wallet-Address-Here?amount=${parseFloat(machine.price) * 1000000000}&text=${encodeURIComponent(`Purchase ${machine.name}`)}`;
      
      // Open TON wallet for payment
      window.open(paymentUrl, '_blank');
      
      toast({
        title: "Payment Initiated",
        description: `Please complete the payment of ${machine.price} TON in your wallet`,
      });
    } catch (error) {
      console.error('Purchase error:', error);
      toast({
        title: "Purchase Failed",
        description: "Failed to initiate payment. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="px-4 pb-6">
      <h2 className="text-lg font-bold mb-4 flex items-center">
        <Settings className="text-primary mr-2" />
        Power Machines
      </h2>
      
      <div className="space-y-3">
        {machines.map((machine: PowerMachine) => {
          const IconComponent = machineIcons[machine.id as keyof typeof machineIcons] || Microchip;
          const colorClass = machineColors[machine.id as keyof typeof machineColors] || "primary";
          
          return (
            <Card 
              key={machine.id} 
              className="bg-card border-border hover:border-primary/50 transition-colors"
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-12 h-12 bg-${colorClass}/20 rounded-lg flex items-center justify-center`}>
                      <IconComponent className={`text-${colorClass} text-lg`} />
                    </div>
                    <div>
                      <h3 className="font-semibold" data-testid={`text-machine-name-${machine.id}`}>
                        {machine.name}
                      </h3>
                      <p className="text-sm text-muted-foreground" data-testid={`text-machine-power-${machine.id}`}>
                        {machine.power.toLocaleString()} Hz
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="ton-gradient text-transparent bg-clip-text font-bold" data-testid={`text-machine-price-${machine.id}`}>
                      {machine.price} TON
                    </div>
                    <Button 
                      className="bg-primary text-primary-foreground px-3 py-1 rounded-md text-sm mt-1"
                      onClick={() => handlePurchase(machine)}
                      data-testid={`button-buy-machine-${machine.id}`}
                    >
                      Buy
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
