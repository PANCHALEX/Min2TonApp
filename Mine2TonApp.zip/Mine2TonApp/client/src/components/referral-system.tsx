import { useState } from "react";
import { useTelegram } from "@/hooks/use-telegram";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Users, Copy, Share } from "lucide-react";

export function ReferralSystem() {
  const { user } = useTelegram();
  const { toast } = useToast();
  const [isSharing, setIsSharing] = useState(false);

  const referralLink = `https://t.me/Mine2TonBot?start=${user?.id || ''}`;
  const referralCode = `REF_${user?.id || ''}`;

  const handleInvite = async () => {
    setIsSharing(true);
    
    try {
      if (navigator.share) {
        await navigator.share({
          title: 'Mine2Ton - Crypto Mining Game',
          text: '🚀 Join me on Mine2Ton! Mine cryptocurrency with your roulette wheel and earn TON. Get started now!',
          url: referralLink,
        });
      } else {
        // Fallback to copying link
        await navigator.clipboard.writeText(referralLink);
        toast({
          title: "Link Copied!",
          description: "Referral link copied to clipboard. Share it with your friends!",
        });
      }
    } catch (error) {
      console.error('Share error:', error);
      toast({
        title: "Share Failed",
        description: "Unable to share. Try copying the link manually.",
        variant: "destructive",
      });
    } finally {
      setIsSharing(false);
    }
  };

  const copyReferralCode = async () => {
    try {
      await navigator.clipboard.writeText(referralCode);
      toast({
        title: "Code Copied!",
        description: "Referral code copied to clipboard.",
      });
    } catch (error) {
      console.error('Copy error:', error);
    }
  };

  return (
    <div className="px-4 pb-6">
      <Card className="bg-gradient-to-r from-secondary/20 to-accent/20 border-secondary/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="font-semibold flex items-center">
                <Users className="text-secondary mr-2" />
                Invite Friends
              </h3>
              <p className="text-sm text-muted-foreground">Earn 1 TON per invite</p>
            </div>
            <Button 
              className="bg-secondary text-secondary-foreground px-4 py-2 rounded-lg font-medium"
              onClick={handleInvite}
              disabled={isSharing}
              data-testid="button-invite"
            >
              {isSharing ? (
                <div className="animate-spin w-4 h-4 border-2 border-secondary-foreground border-t-transparent rounded-full" />
              ) : (
                <>
                  <Share className="w-4 h-4 mr-2" />
                  Invite
                </>
              )}
            </Button>
          </div>
          
          {/* Referral Code Display */}
          <div className="bg-muted/50 rounded-lg p-3 mb-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Your Referral Code</p>
                <p className="font-mono text-sm" data-testid="text-referral-code">{referralCode}</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={copyReferralCode}
                data-testid="button-copy-code"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="pt-3 border-t border-border/50">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Invited:</span>
              <span className="font-medium" data-testid="text-referral-count">
                {user?.totalReferrals || 0} friends
              </span>
            </div>
            <div className="flex justify-between text-sm mt-1">
              <span className="text-muted-foreground">Earned:</span>
              <span className="font-medium text-accent" data-testid="text-referral-earnings">
                {user?.totalReferrals || 0} TON
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
