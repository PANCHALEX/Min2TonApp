import { useState, useRef, useEffect } from "react";
import { useMining } from "@/hooks/use-mining";
import { useTelegram } from "@/hooks/use-telegram";
import { useToast } from "@/hooks/use-toast";
import { Coins } from "lucide-react";

export function RouletteWheel() {
  const [isSpinning, setIsSpinning] = useState(false);
  const [spinSpeed, setSpinSpeed] = useState('slow');
  const [currentEarning, setCurrentEarning] = useState('0.001');
  const wheelRef = useRef<HTMLDivElement>(null);
  const { user } = useTelegram();
  const { sendMiningAction, miningData } = useMining();
  const { toast } = useToast();

  useEffect(() => {
    // Auto-rotation for mining effect
    if (wheelRef.current) {
      wheelRef.current.style.animation = `spin 8s linear infinite`;
    }
  }, []);

  const handleWheelTap = async () => {
    if (!user || isSpinning) return;

    setIsSpinning(true);
    
    // Visual feedback
    if (wheelRef.current) {
      wheelRef.current.style.transform = 'scale(0.95)';
      setTimeout(() => {
        if (wheelRef.current) {
          wheelRef.current.style.transform = 'scale(1)';
        }
      }, 100);
    }

    // Temporarily increase spin speed
    setSpinSpeed('fast');
    if (wheelRef.current) {
      wheelRef.current.style.animation = `spin 2s linear infinite`;
    }

    // Send mining action
    await sendMiningAction();

    // Calculate earning based on mining power
    const baseReward = 0.001;
    const powerMultiplier = (miningData?.miningPower || 10000) / 10000;
    const speedMultiplier = miningData?.wheelSpeed || 1;
    const reward = baseReward * powerMultiplier * speedMultiplier;
    
    setCurrentEarning(reward.toFixed(3));

    // Show earning notification
    toast({
      title: "Mining Successful!",
      description: `+${reward.toFixed(3)} LP earned`,
      className: "bg-secondary text-secondary-foreground",
    });

    // Reset to normal speed after 3 seconds
    setTimeout(() => {
      setSpinSpeed('slow');
      if (wheelRef.current) {
        wheelRef.current.style.animation = `spin 8s linear infinite`;
      }
      setIsSpinning(false);
    }, 3000);
  };

  return (
    <div className="px-4 pb-8">
      <div className="relative">
        {/* Wheel Container */}
        <div className="flex justify-center items-center">
          <div className="relative">
            {/* Roulette Wheel */}
            <div 
              ref={wheelRef}
              className={`w-64 h-64 rounded-full roulette-wheel tap-zone cursor-pointer relative border-4 border-primary mining-active ${isSpinning ? 'animate-spin-fast' : 'animate-spin-slow'}`}
              onClick={handleWheelTap}
              data-testid="roulette-wheel"
            >
              {/* Center Hub */}
              <div className="absolute inset-8 bg-card rounded-full border-4 border-border flex items-center justify-center">
                <div className="text-center">
                  <Coins className="text-accent text-2xl mb-2 mx-auto" />
                  <p className="text-xs font-medium">TAP TO</p>
                  <p className="text-xs font-medium">MINE</p>
                </div>
              </div>
            </div>
            
            {/* Pointer */}
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-2">
              <div className="w-0 h-0 border-l-4 border-r-4 border-b-8 border-l-transparent border-r-transparent border-b-accent"></div>
            </div>
          </div>
        </div>

        {/* Live Points Indicator */}
        <div className="mt-6 text-center">
          <div className="inline-flex items-center bg-secondary/20 rounded-full px-6 py-3 border border-secondary/30">
            <span className="text-secondary mr-2">+</span>
            <span className="text-lg font-bold text-secondary number-font" data-testid="text-current-earning">
              {currentEarning}
            </span>
            <span className="text-sm text-muted-foreground ml-1">LP</span>
          </div>
        </div>
      </div>
    </div>
  );
}
