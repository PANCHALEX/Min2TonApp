import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useTelegram } from "@/hooks/use-telegram";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Wallet, X } from "lucide-react";

export function WithdrawalModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [address, setAddress] = useState("");
  const { user } = useTelegram();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const withdrawalMutation = useMutation({
    mutationFn: async (data: { userId: string; amount: string; tonAddress: string }) => {
      const response = await apiRequest("POST", "/api/withdrawal-request", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Withdrawal Requested",
        description: "Your withdrawal request has been submitted and will be processed within 24 hours.",
      });
      setIsOpen(false);
      setAmount("");
      setAddress("");
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
    },
    onError: (error: any) => {
      toast({
        title: "Withdrawal Failed",
        description: error.message || "Failed to process withdrawal request",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) return;
    
    const withdrawAmount = parseFloat(amount);
    const userBalance = parseFloat(user.tonBalance || "0");

    if (withdrawAmount < 250) {
      toast({
        title: "Invalid Amount",
        description: "Minimum withdrawal amount is 250 TON",
        variant: "destructive",
      });
      return;
    }

    if (withdrawAmount > userBalance) {
      toast({
        title: "Insufficient Balance",
        description: "You don't have enough TON balance for this withdrawal",
        variant: "destructive",
      });
      return;
    }

    if (!address.startsWith("UQ") && !address.startsWith("EQ")) {
      toast({
        title: "Invalid Address",
        description: "Please enter a valid TON wallet address",
        variant: "destructive",
      });
      return;
    }

    withdrawalMutation.mutate({
      userId: user.id,
      amount,
      tonAddress: address,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          className="bg-accent text-accent-foreground py-3 px-4 rounded-lg font-semibold flex items-center justify-center space-x-2 hover:opacity-90 transition-opacity"
          data-testid="button-open-withdrawal"
        >
          <Wallet className="h-4 w-4" />
          <span>Withdraw</span>
        </Button>
      </DialogTrigger>
      
      <DialogContent className="bg-card border-border max-w-md mx-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Withdraw TON</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <Card className="bg-muted border-border">
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Available:</span>
                <span className="font-bold text-accent" data-testid="text-available-balance">
                  {user?.tonBalance || '0'} TON
                </span>
              </div>
              <div className="flex justify-between items-center mt-2">
                <span className="text-muted-foreground">Minimum:</span>
                <span className="font-medium">250 TON</span>
              </div>
            </CardContent>
          </Card>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label className="block text-sm font-medium mb-2">Withdrawal Amount</Label>
              <Input 
                type="number" 
                placeholder="Enter amount..." 
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-input border-border"
                min="250"
                step="0.001"
                required
                data-testid="input-withdrawal-amount"
              />
            </div>
            
            <div>
              <Label className="block text-sm font-medium mb-2">TON Wallet Address</Label>
              <Input 
                type="text" 
                placeholder="UQ..." 
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full bg-input border-border"
                required
                data-testid="input-ton-address"
              />
            </div>
            
            <Button 
              type="submit"
              className="w-full bg-accent text-accent-foreground py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity"
              disabled={withdrawalMutation.isPending || !amount || !address}
              data-testid="button-submit-withdrawal"
            >
              {withdrawalMutation.isPending ? (
                <div className="animate-spin w-4 h-4 border-2 border-accent-foreground border-t-transparent rounded-full" />
              ) : (
                'Withdraw TON'
              )}
            </Button>
            
            <p className="text-xs text-muted-foreground text-center">
              Withdrawals are processed within 24 hours
            </p>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}
