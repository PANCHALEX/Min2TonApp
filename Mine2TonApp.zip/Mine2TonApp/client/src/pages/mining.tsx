import { useEffect } from "react";
import { useTelegram } from "@/hooks/use-telegram";
import { useMining } from "@/hooks/use-mining";
import { RouletteWheel } from "@/components/roulette-wheel";
import { PowerMachines } from "@/components/power-machines";
import { ReferralSystem } from "@/components/referral-system";
import { WithdrawalModal } from "@/components/withdrawal-modal";
import { AccelerationModal } from "@/components/acceleration-modal";
import { ChannelSubscription } from "@/components/channel-subscription";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Coins, Settings, Bolt, Wallet, Users, ChartLine } from "lucide-react";

export default function MiningPage() {
  const { user, initData, isReady } = useTelegram();
  const { miningData, isConnected, connectWebSocket } = useMining();

  useEffect(() => {
    if (isReady && user) {
      connectWebSocket(user.id.toString());
    }
  }, [isReady, user, connectWebSocket]);

  if (!isReady || !user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading Mine2Ton...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto bg-background min-h-screen relative">
      {/* Header Section */}
      <div className="flex items-center justify-between p-4 bg-card border-b border-border" data-testid="header-container">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
            <Coins className="text-primary-foreground text-sm" />
          </div>
          <div>
            <h1 className="text-lg font-bold" data-testid="app-title">Mine2Ton</h1>
            <p className="text-xs text-muted-foreground" data-testid="user-username">
              @{user.username || 'user'}
            </p>
          </div>
        </div>
        <Button 
          variant="ghost" 
          size="icon"
          className="w-8 h-8 text-muted-foreground hover:text-foreground"
          data-testid="button-settings"
        >
          <Settings className="h-4 w-4" />
        </Button>
      </div>

      {/* Channel Subscription Notice */}
      <ChannelSubscription />

      {/* Stats Overview */}
      <div className="px-4 py-6">
        <div className="grid grid-cols-2 gap-4">
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-muted-foreground text-sm">Total LP</p>
                <p className="text-2xl font-bold text-secondary number-font" data-testid="text-total-lp">
                  {miningData?.totalLP || '0.000'}
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-muted-foreground text-sm">TON Balance</p>
                <p className="text-2xl font-bold text-accent number-font" data-testid="text-ton-balance">
                  {miningData?.tonBalance || '0.000'}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Mining Rate Display */}
        <div className="mt-4 bg-muted rounded-lg p-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Mining Rate</span>
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium" data-testid="text-mining-rate">
                {(0.001 * (miningData?.miningPower || 10000) / 10000 * (miningData?.wheelSpeed || 1)).toFixed(3)}
              </span>
              <span className="text-xs text-muted-foreground">LP/spin</span>
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-secondary animate-pulse' : 'bg-muted-foreground'}`}></div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Roulette Section */}
      <RouletteWheel />

      {/* Action Buttons */}
      <div className="px-4 pb-6">
        <div className="grid grid-cols-2 gap-3">
          <Button 
            className="bg-primary text-primary-foreground py-3 px-4 rounded-lg font-semibold flex items-center justify-center space-x-2 hover:opacity-90 transition-opacity"
            data-testid="button-upgrades"
          >
            <Bolt className="h-4 w-4" />
            <span>Upgrades</span>
          </Button>
          <Button 
            className="bg-accent text-accent-foreground py-3 px-4 rounded-lg font-semibold flex items-center justify-center space-x-2 hover:opacity-90 transition-opacity"
            data-testid="button-withdraw"
          >
            <Wallet className="h-4 w-4" />
            <span>Withdraw</span>
          </Button>
        </div>
      </div>

      {/* Power Machines Section */}
      <PowerMachines />

      {/* Referral Section */}
      <ReferralSystem />

      {/* Mining Analytics Section */}
      <div className="px-4 pb-20">
        <h2 className="text-lg font-bold mb-4 flex items-center">
          <ChartLine className="text-secondary mr-2" />
          Mining Stats
        </h2>
        
        <div className="grid grid-cols-2 gap-4">
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <p className="text-muted-foreground text-sm">Today's Earnings</p>
              <p className="text-xl font-bold text-secondary number-font" data-testid="text-daily-earnings">
                {miningData?.dailyEarnings || '0.000'}
              </p>
              <p className="text-xs text-muted-foreground">LP</p>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <p className="text-muted-foreground text-sm">Total Spins</p>
              <p className="text-xl font-bold text-primary number-font" data-testid="text-total-spins">
                {miningData?.totalSpins || '0'}
              </p>
              <p className="text-xs text-muted-foreground">spins</p>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <p className="text-muted-foreground text-sm">Mining Power</p>
              <p className="text-xl font-bold text-accent number-font" data-testid="text-mining-power">
                {miningData?.miningPower || '10,000'}
              </p>
              <p className="text-xs text-muted-foreground">Hz</p>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <p className="text-muted-foreground text-sm">Efficiency</p>
              <p className="text-xl font-bold text-foreground number-font" data-testid="text-efficiency">
                {isConnected ? '98.5%' : '0%'}
              </p>
              <p className="text-xs text-muted-foreground">uptime</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Navigation Bar */}
      <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-card border-t border-border" data-testid="bottom-navigation">
        <div className="grid grid-cols-4 py-3">
          <Button 
            variant="ghost" 
            className="flex flex-col items-center space-y-1 text-primary"
            data-testid="nav-mine"
          >
            <Coins className="text-lg" />
            <span className="text-xs font-medium">Mine</span>
          </Button>
          <Button 
            variant="ghost" 
            className="flex flex-col items-center space-y-1 text-muted-foreground hover:text-foreground"
            data-testid="nav-upgrades"
          >
            <Bolt className="text-lg" />
            <span className="text-xs font-medium">Upgrades</span>
          </Button>
          <Button 
            variant="ghost" 
            className="flex flex-col items-center space-y-1 text-muted-foreground hover:text-foreground"
            data-testid="nav-friends"
          >
            <Users className="text-lg" />
            <span className="text-xs font-medium">Friends</span>
          </Button>
          <Button 
            variant="ghost" 
            className="flex flex-col items-center space-y-1 text-muted-foreground hover:text-foreground"
            data-testid="nav-wallet"
          >
            <Wallet className="text-lg" />
            <span className="text-xs font-medium">Wallet</span>
          </Button>
        </div>
      </div>

      {/* Modals */}
      <WithdrawalModal />
      <AccelerationModal />
    </div>
  );
}
