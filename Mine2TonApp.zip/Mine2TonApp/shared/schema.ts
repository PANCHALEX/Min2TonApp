import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  telegramId: text("telegram_id").notNull().unique(),
  username: text("username"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  totalLP: decimal("total_lp", { precision: 12, scale: 3 }).default("0").notNull(),
  tonBalance: decimal("ton_balance", { precision: 12, scale: 3 }).default("0").notNull(),
  miningPower: integer("mining_power").default(10000).notNull(), // Hz
  wheelSpeed: integer("wheel_speed").default(1).notNull(), // Speed multiplier
  isChannelSubscribed: boolean("is_channel_subscribed").default(false).notNull(),
  referralCode: text("referral_code").unique(),
  referredBy: text("referred_by"),
  totalReferrals: integer("total_referrals").default(0).notNull(),
  totalSpins: integer("total_spins").default(0).notNull(),
  dailyEarnings: decimal("daily_earnings", { precision: 12, scale: 3 }).default("0").notNull(),
  lastMiningUpdate: timestamp("last_mining_update").defaultNow(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull().references(() => users.id),
  type: text("type").notNull(), // "purchase", "withdrawal", "referral_bonus"
  amount: decimal("amount", { precision: 12, scale: 3 }).notNull(),
  currency: text("currency").notNull(), // "TON", "LP"
  description: text("description").notNull(),
  status: text("status").default("pending").notNull(), // "pending", "completed", "failed"
  tonTxHash: text("ton_tx_hash"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const powerMachines = pgTable("power_machines", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  power: integer("power").notNull(), // Hz
  price: decimal("price", { precision: 12, scale: 3 }).notNull(), // TON
  description: text("description"),
});

export const userMachines = pgTable("user_machines", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull().references(() => users.id),
  machineId: text("machine_id").notNull().references(() => powerMachines.id),
  purchasedAt: timestamp("purchased_at").defaultNow().notNull(),
});

export const withdrawalRequests = pgTable("withdrawal_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull().references(() => users.id),
  amount: decimal("amount", { precision: 12, scale: 3 }).notNull(),
  tonAddress: text("ton_address").notNull(),
  status: text("status").default("pending").notNull(),
  processedAt: timestamp("processed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  lastMiningUpdate: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

export const insertWithdrawalRequestSchema = createInsertSchema(withdrawalRequests).omit({
  id: true,
  createdAt: true,
  processedAt: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type PowerMachine = typeof powerMachines.$inferSelect;
export type UserMachine = typeof userMachines.$inferSelect;
export type WithdrawalRequest = typeof withdrawalRequests.$inferSelect;
export type InsertWithdrawalRequest = z.infer<typeof insertWithdrawalRequestSchema>;
