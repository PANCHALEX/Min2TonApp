import { type User, type InsertUser, type Transaction, type InsertTransaction, type PowerMachine, type UserMachine, type WithdrawalRequest, type InsertWithdrawalRequest } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User management
  getUser(id: string): Promise<User | undefined>;
  getUserByTelegramId(telegramId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;

  // Mining operations
  updateUserLP(userId: string, lpAmount: number): Promise<void>;
  updateUserSpins(userId: string): Promise<void>;
  updateDailyEarnings(userId: string, amount: number): Promise<void>;

  // Transactions
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getUserTransactions(userId: string): Promise<Transaction[]>;
  updateTransactionStatus(id: string, status: string, tonTxHash?: string): Promise<void>;

  // Power machines
  getPowerMachines(): Promise<PowerMachine[]>;
  getUserMachines(userId: string): Promise<UserMachine[]>;
  purchaseMachine(userId: string, machineId: string): Promise<UserMachine>;

  // Withdrawals
  createWithdrawalRequest(request: InsertWithdrawalRequest): Promise<WithdrawalRequest>;
  getWithdrawalRequests(userId: string): Promise<WithdrawalRequest[]>;
  updateWithdrawalStatus(id: string, status: string): Promise<void>;

  // Referrals
  updateReferralCount(userId: string): Promise<void>;
  getUserByReferralCode(code: string): Promise<User | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private transactions: Map<string, Transaction>;
  private powerMachines: Map<string, PowerMachine>;
  private userMachines: Map<string, UserMachine>;
  private withdrawalRequests: Map<string, WithdrawalRequest>;

  constructor() {
    this.users = new Map();
    this.transactions = new Map();
    this.userMachines = new Map();
    this.withdrawalRequests = new Map();
    
    // Initialize power machines
    this.powerMachines = new Map();
    const machines: PowerMachine[] = [
      {
        id: "basic-miner",
        name: "Basic Miner",
        power: 10000,
        price: "3",
        description: "10,000 Hz mining power"
      },
      {
        id: "pro-miner",
        name: "Pro Miner",
        power: 20000,
        price: "5",
        description: "20,000 Hz mining power"
      },
      {
        id: "ultra-miner",
        name: "Ultra Miner",
        power: 30000,
        price: "10",
        description: "30,000 Hz mining power"
      }
    ];
    machines.forEach(machine => this.powerMachines.set(machine.id, machine));
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByTelegramId(telegramId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.telegramId === telegramId,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const referralCode = `REF_${Math.random().toString(36).substr(2, 8).toUpperCase()}`;
    const user: User = { 
      ...insertUser, 
      id,
      referralCode,
      totalLP: "0",
      tonBalance: "0",
      miningPower: 10000,
      wheelSpeed: 1,
      isChannelSubscribed: false,
      totalReferrals: 0,
      totalSpins: 0,
      dailyEarnings: "0",
      lastMiningUpdate: new Date(),
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async updateUserLP(userId: string, lpAmount: number): Promise<void> {
    const user = this.users.get(userId);
    if (!user) return;
    
    const currentLP = parseFloat(user.totalLP);
    const newLP = currentLP + lpAmount;
    await this.updateUser(userId, { totalLP: newLP.toFixed(3) });
  }

  async updateUserSpins(userId: string): Promise<void> {
    const user = this.users.get(userId);
    if (!user) return;
    
    await this.updateUser(userId, { totalSpins: user.totalSpins + 1 });
  }

  async updateDailyEarnings(userId: string, amount: number): Promise<void> {
    const user = this.users.get(userId);
    if (!user) return;
    
    const currentDaily = parseFloat(user.dailyEarnings);
    const newDaily = currentDaily + amount;
    await this.updateUser(userId, { dailyEarnings: newDaily.toFixed(3) });
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = randomUUID();
    const transaction: Transaction = {
      ...insertTransaction,
      id,
      createdAt: new Date(),
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async getUserTransactions(userId: string): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(
      (transaction) => transaction.userId === userId,
    );
  }

  async updateTransactionStatus(id: string, status: string, tonTxHash?: string): Promise<void> {
    const transaction = this.transactions.get(id);
    if (!transaction) return;
    
    const updated = { ...transaction, status, tonTxHash };
    this.transactions.set(id, updated);
  }

  async getPowerMachines(): Promise<PowerMachine[]> {
    return Array.from(this.powerMachines.values());
  }

  async getUserMachines(userId: string): Promise<UserMachine[]> {
    return Array.from(this.userMachines.values()).filter(
      (userMachine) => userMachine.userId === userId,
    );
  }

  async purchaseMachine(userId: string, machineId: string): Promise<UserMachine> {
    const id = randomUUID();
    const userMachine: UserMachine = {
      id,
      userId,
      machineId,
      purchasedAt: new Date(),
    };
    this.userMachines.set(id, userMachine);
    return userMachine;
  }

  async createWithdrawalRequest(insertRequest: InsertWithdrawalRequest): Promise<WithdrawalRequest> {
    const id = randomUUID();
    const request: WithdrawalRequest = {
      ...insertRequest,
      id,
      status: "pending",
      processedAt: null,
      createdAt: new Date(),
    };
    this.withdrawalRequests.set(id, request);
    return request;
  }

  async getWithdrawalRequests(userId: string): Promise<WithdrawalRequest[]> {
    return Array.from(this.withdrawalRequests.values()).filter(
      (request) => request.userId === userId,
    );
  }

  async updateWithdrawalStatus(id: string, status: string): Promise<void> {
    const request = this.withdrawalRequests.get(id);
    if (!request) return;
    
    const updated = { 
      ...request, 
      status, 
      processedAt: status === "completed" ? new Date() : request.processedAt 
    };
    this.withdrawalRequests.set(id, updated);
  }

  async updateReferralCount(userId: string): Promise<void> {
    const user = this.users.get(userId);
    if (!user) return;
    
    await this.updateUser(userId, { totalReferrals: user.totalReferrals + 1 });
  }

  async getUserByReferralCode(code: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.referralCode === code,
    );
  }
}

export const storage = new MemStorage();
