import crypto from 'crypto';

export class TelegramBot {
  private botToken: string;
  private channelId: string;

  constructor() {
    this.botToken = process.env.TELEGRAM_BOT_TOKEN || "8484176155:AAFt7nlmXvLwh3Qxhs1OcTQ_8wjnzdkThn4";
    this.channelId = process.env.TELEGRAM_CHANNEL || "@mine2tonchannel";
  }

  async handleWebhook(update: any) {
    try {
      if (update.message && update.message.text === '/mine') {
        const chatId = update.message.chat.id;
        const userId = update.message.from.id;
        
        // Send mine button with Web App
        await this.sendMineButton(chatId, userId);
      }
      
      if (update.message && update.message.text === '/start') {
        const chatId = update.message.chat.id;
        const userId = update.message.from.id;
        
        // Check for referral code
        const text = update.message.text;
        const referralCode = text.split(' ')[1];
        
        await this.sendWelcomeMessage(chatId, userId, referralCode);
      }
    } catch (error) {
      console.error('Webhook handling error:', error);
    }
  }

  async sendMineButton(chatId: number, userId: number) {
    const webAppUrl = process.env.WEB_APP_URL || `https://${process.env.REPLIT_DOMAINS?.split(',')[0] || 'localhost:5000'}`;
    
    const keyboard = {
      inline_keyboard: [
        [
          {
            text: "⛏️ Start Mining",
            web_app: { url: webAppUrl }
          }
        ],
        [
          {
            text: "📢 Join Channel",
            url: `https://t.me/${this.channelId.replace('@', '')}`
          }
        ]
      ]
    };

    await this.sendMessage(chatId, "🚀 Welcome to Mine2Ton!\n\nTap the button below to start mining cryptocurrency with your roulette wheel!", keyboard);
  }

  async sendWelcomeMessage(chatId: number, userId: number, referralCode?: string) {
    const webAppUrl = process.env.WEB_APP_URL || `https://${process.env.REPLIT_DOMAINS?.split(',')[0] || 'localhost:5000'}`;
    
    let message = "🎯 Welcome to Mine2Ton - The Ultimate Crypto Mining Game!\n\n";
    message += "🎰 Spin the roulette wheel to mine LP points\n";
    message += "💰 Convert 1000 LP to 1 TON\n";
    message += "⚡ Upgrade your mining power\n";
    message += "👥 Invite friends and earn 1 TON each\n\n";
    
    if (referralCode) {
      message += `🎁 You were invited by a friend! You'll both get bonuses!\n\n`;
    }
    
    message += "Tap 'Start Mining' to begin your crypto journey!";

    const keyboard = {
      inline_keyboard: [
        [
          {
            text: "⛏️ Start Mining",
            web_app: { url: `${webAppUrl}${referralCode ? `?ref=${referralCode}` : ''}` }
          }
        ],
        [
          {
            text: "📢 Join Channel",
            url: `https://t.me/${this.channelId.replace('@', '')}`
          }
        ]
      ]
    };

    await this.sendMessage(chatId, message, keyboard);
  }

  async sendMessage(chatId: number, text: string, replyMarkup?: any) {
    try {
      const url = `https://api.telegram.org/bot${this.botToken}/sendMessage`;
      const body = {
        chat_id: chatId,
        text: text,
        parse_mode: 'HTML',
        reply_markup: replyMarkup
      };

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        throw new Error(`Telegram API error: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Send message error:', error);
      throw error;
    }
  }

  verifyTelegramAuth(authData: any): boolean {
    try {
      const { hash, ...data } = authData;
      
      // Create data check string
      const dataCheckArr = Object.keys(data)
        .sort()
        .map(key => `${key}=${data[key]}`);
      const dataCheckString = dataCheckArr.join('\n');
      
      // Create secret key
      const secretKey = crypto
        .createHmac('sha256', 'WebAppData')
        .update(this.botToken)
        .digest();
      
      // Calculate hash
      const calculatedHash = crypto
        .createHmac('sha256', secretKey)
        .update(dataCheckString)
        .digest('hex');
      
      return calculatedHash === hash;
    } catch (error) {
      console.error('Auth verification error:', error);
      return false;
    }
  }

  async setWebhook(url: string) {
    try {
      const webhookUrl = `https://api.telegram.org/bot${this.botToken}/setWebhook`;
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          url: `${url}/api/telegram-webhook`,
          allowed_updates: ['message', 'callback_query']
        }),
      });

      const result = await response.json();
      console.log('Webhook set:', result);
      return result;
    } catch (error) {
      console.error('Set webhook error:', error);
      throw error;
    }
  }
}
