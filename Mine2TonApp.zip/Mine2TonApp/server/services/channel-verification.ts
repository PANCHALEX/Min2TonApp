export class ChannelVerification {
  private botToken: string;
  private channelId: string;

  constructor() {
    this.botToken = process.env.TELEGRAM_BOT_TOKEN || "8484176155:AAFt7nlmXvLwh3Qxhs1OcTQ_8wjnzdkThn4";
    this.channelId = process.env.TELEGRAM_CHANNEL || "@mine2tonchannel";
  }

  async checkSubscription(telegramId: string): Promise<boolean> {
    try {
      const url = `https://api.telegram.org/bot${this.botToken}/getChatMember`;
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: this.channelId,
          user_id: telegramId
        }),
      });

      if (!response.ok) {
        console.error('Telegram API error:', response.statusText);
        return false;
      }

      const data = await response.json();
      
      if (!data.ok) {
        console.error('Telegram API error:', data.description);
        return false;
      }

      const status = data.result.status;
      // User is subscribed if they are: creator, administrator, member, or restricted
      const validStatuses = ['creator', 'administrator', 'member', 'restricted'];
      
      return validStatuses.includes(status);
    } catch (error) {
      console.error('Subscription check error:', error);
      return false;
    }
  }

  async sendSubscriptionReminder(telegramId: string) {
    try {
      const url = `https://api.telegram.org/bot${this.botToken}/sendMessage`;
      const message = `🔔 Don't forget to subscribe to ${this.channelId} to unlock mining features!`;
      
      const keyboard = {
        inline_keyboard: [
          [
            {
              text: "📢 Subscribe Now",
              url: `https://t.me/${this.channelId.replace('@', '')}`
            }
          ]
        ]
      };

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: telegramId,
          text: message,
          reply_markup: keyboard
        }),
      });

      return await response.json();
    } catch (error) {
      console.error('Send subscription reminder error:', error);
    }
  }
}
