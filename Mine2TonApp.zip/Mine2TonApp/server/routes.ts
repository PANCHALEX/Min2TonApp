import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { z } from "zod";
import { storage } from "./storage";
import { insertUserSchema, insertTransactionSchema, insertWithdrawalRequestSchema } from "@shared/schema";
import { TelegramBot } from "./services/telegram-bot";
import { TonPayments } from "./services/ton-payments";
import { ChannelVerification } from "./services/channel-verification";

const bot = new TelegramBot();
const tonPayments = new TonPayments();
const channelVerification = new ChannelVerification();

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time mining updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  const clients = new Map<string, WebSocket>();

  wss.on('connection', (ws, req) => {
    console.log('WebSocket client connected');
    
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        if (data.type === 'authenticate' && data.telegramId) {
          clients.set(data.telegramId, ws);
          console.log(`Client authenticated: ${data.telegramId}`);
        }
        
        if (data.type === 'mine' && data.telegramId) {
          await handleMining(data.telegramId, ws);
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      // Remove client from map
      for (const [telegramId, client] of clients.entries()) {
        if (client === ws) {
          clients.delete(telegramId);
          break;
        }
      }
      console.log('WebSocket client disconnected');
    });
  });

  async function handleMining(telegramId: string, ws: WebSocket) {
    const user = await storage.getUserByTelegramId(telegramId);
    if (!user) return;

    // Check channel subscription
    if (!user.isChannelSubscribed) {
      const isSubscribed = await channelVerification.checkSubscription(telegramId);
      if (!isSubscribed) {
        ws.send(JSON.stringify({
          type: 'subscription_required',
          message: 'Please subscribe to @mine2tonchannel to start mining'
        }));
        return;
      }
      await storage.updateUser(user.id, { isChannelSubscribed: true });
    }

    // Calculate mining reward based on user's power
    const baseReward = 0.001;
    const powerMultiplier = user.miningPower / 10000;
    const speedMultiplier = user.wheelSpeed;
    const reward = baseReward * powerMultiplier * speedMultiplier;

    // Update user stats
    await storage.updateUserLP(user.id, reward);
    await storage.updateUserSpins(user.id);
    await storage.updateDailyEarnings(user.id, reward);

    // Update TON balance if applicable (1000 LP = 1 TON)
    const updatedUser = await storage.getUser(user.id);
    if (updatedUser) {
      const totalLP = parseFloat(updatedUser.totalLP);
      const tonEarned = Math.floor(totalLP / 1000);
      const remainingLP = totalLP - (tonEarned * 1000);
      
      if (tonEarned > parseFloat(updatedUser.tonBalance)) {
        await storage.updateUser(user.id, { 
          tonBalance: tonEarned.toString(),
          totalLP: remainingLP.toFixed(3)
        });
      }
    }

    // Send update to client
    const finalUser = await storage.getUser(user.id);
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'mining_update',
        reward: reward.toFixed(3),
        totalLP: finalUser?.totalLP,
        tonBalance: finalUser?.tonBalance,
        totalSpins: finalUser?.totalSpins,
        dailyEarnings: finalUser?.dailyEarnings
      }));
    }
  }

  // Telegram webhook endpoint
  app.post("/api/telegram-webhook", async (req, res) => {
    try {
      await bot.handleWebhook(req.body);
      res.status(200).send('OK');
    } catch (error) {
      console.error('Webhook error:', error);
      res.status(500).send('Error');
    }
  });

  // User authentication/registration
  app.post("/api/auth/telegram", async (req, res) => {
    try {
      const telegramData = z.object({
        id: z.string(),
        username: z.string().optional(),
        first_name: z.string().optional(),
        last_name: z.string().optional(),
        auth_date: z.number(),
        hash: z.string(),
      }).parse(req.body);

      // Verify Telegram auth data
      const isValid = bot.verifyTelegramAuth(telegramData);
      if (!isValid) {
        return res.status(401).json({ error: "Invalid Telegram authentication" });
      }

      let user = await storage.getUserByTelegramId(telegramData.id);
      
      if (!user) {
        // Create new user
        const newUser = await storage.createUser({
          telegramId: telegramData.id,
          username: telegramData.username || null,
          firstName: telegramData.first_name || null,
          lastName: telegramData.last_name || null,
          referredBy: null,
        });
        user = newUser;
      }

      res.json({ user });
    } catch (error) {
      console.error('Auth error:', error);
      res.status(500).json({ error: "Authentication failed" });
    }
  });

  // Get user profile
  app.get("/api/user/:telegramId", async (req, res) => {
    try {
      const user = await storage.getUserByTelegramId(req.params.telegramId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json({ user });
    } catch (error) {
      console.error('Get user error:', error);
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  // Check channel subscription
  app.post("/api/check-subscription", async (req, res) => {
    try {
      const { telegramId } = z.object({ telegramId: z.string() }).parse(req.body);
      
      const isSubscribed = await channelVerification.checkSubscription(telegramId);
      
      if (isSubscribed) {
        await storage.updateUser(telegramId, { isChannelSubscribed: true });
      }
      
      res.json({ isSubscribed });
    } catch (error) {
      console.error('Subscription check error:', error);
      res.status(500).json({ error: "Failed to check subscription" });
    }
  });

  // Get power machines
  app.get("/api/power-machines", async (req, res) => {
    try {
      const machines = await storage.getPowerMachines();
      res.json({ machines });
    } catch (error) {
      console.error('Get machines error:', error);
      res.status(500).json({ error: "Failed to get power machines" });
    }
  });

  // Purchase power machine
  app.post("/api/purchase-machine", async (req, res) => {
    try {
      const { userId, machineId, tonTxHash } = z.object({
        userId: z.string(),
        machineId: z.string(),
        tonTxHash: z.string(),
      }).parse(req.body);

      // Verify TON transaction
      const machines = await storage.getPowerMachines();
      const machine = machines.find(m => m.id === machineId);
      if (!machine) {
        return res.status(404).json({ error: "Machine not found" });
      }

      const isValidPayment = await tonPayments.verifyPayment(tonTxHash, machine.price);
      if (!isValidPayment) {
        return res.status(400).json({ error: "Invalid payment" });
      }

      // Purchase machine
      const userMachine = await storage.purchaseMachine(userId, machineId);
      
      // Update user mining power
      const user = await storage.getUser(userId);
      if (user) {
        const newPower = user.miningPower + machine.power;
        await storage.updateUser(userId, { miningPower: newPower });
      }

      // Create transaction record
      await storage.createTransaction({
        userId,
        type: "purchase",
        amount: machine.price,
        currency: "TON",
        description: `Purchased ${machine.name}`,
        status: "completed",
        tonTxHash,
      });

      res.json({ userMachine });
    } catch (error) {
      console.error('Purchase machine error:', error);
      res.status(500).json({ error: "Failed to purchase machine" });
    }
  });

  // Purchase wheel acceleration
  app.post("/api/purchase-acceleration", async (req, res) => {
    try {
      const { userId, speedMultiplier, price, tonTxHash } = z.object({
        userId: z.string(),
        speedMultiplier: z.number(),
        price: z.string(),
        tonTxHash: z.string(),
      }).parse(req.body);

      // Verify TON transaction
      const isValidPayment = await tonPayments.verifyPayment(tonTxHash, price);
      if (!isValidPayment) {
        return res.status(400).json({ error: "Invalid payment" });
      }

      // Update user wheel speed
      await storage.updateUser(userId, { wheelSpeed: speedMultiplier });

      // Create transaction record
      await storage.createTransaction({
        userId,
        type: "purchase",
        amount: price,
        currency: "TON",
        description: `Purchased ${speedMultiplier}x wheel acceleration`,
        status: "completed",
        tonTxHash,
      });

      res.json({ success: true });
    } catch (error) {
      console.error('Purchase acceleration error:', error);
      res.status(500).json({ error: "Failed to purchase acceleration" });
    }
  });

  // Process referral
  app.post("/api/process-referral", async (req, res) => {
    try {
      const { referralCode, newUserId } = z.object({
        referralCode: z.string(),
        newUserId: z.string(),
      }).parse(req.body);

      const referrer = await storage.getUserByReferralCode(referralCode);
      if (!referrer) {
        return res.status(404).json({ error: "Invalid referral code" });
      }

      // Update referrer stats
      await storage.updateReferralCount(referrer.id);
      
      // Add 1 TON to referrer balance
      const currentBalance = parseFloat(referrer.tonBalance);
      await storage.updateUser(referrer.id, { 
        tonBalance: (currentBalance + 1).toString() 
      });

      // Create transaction record
      await storage.createTransaction({
        userId: referrer.id,
        type: "referral_bonus",
        amount: "1",
        currency: "TON",
        description: "Referral bonus",
        status: "completed",
      });

      // Update new user's referredBy field
      await storage.updateUser(newUserId, { referredBy: referralCode });

      res.json({ success: true });
    } catch (error) {
      console.error('Process referral error:', error);
      res.status(500).json({ error: "Failed to process referral" });
    }
  });

  // Submit withdrawal request
  app.post("/api/withdrawal-request", async (req, res) => {
    try {
      const withdrawalData = insertWithdrawalRequestSchema.parse(req.body);
      
      const user = await storage.getUser(withdrawalData.userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const amount = parseFloat(withdrawalData.amount);
      const balance = parseFloat(user.tonBalance);

      if (amount < 250) {
        return res.status(400).json({ error: "Minimum withdrawal is 250 TON" });
      }

      if (amount > balance) {
        return res.status(400).json({ error: "Insufficient balance" });
      }

      // Create withdrawal request
      const request = await storage.createWithdrawalRequest(withdrawalData);

      // Deduct from user balance
      await storage.updateUser(user.id, { 
        tonBalance: (balance - amount).toString() 
      });

      // Create transaction record
      await storage.createTransaction({
        userId: user.id,
        type: "withdrawal",
        amount: withdrawalData.amount,
        currency: "TON",
        description: "Withdrawal request",
        status: "pending",
      });

      res.json({ request });
    } catch (error) {
      console.error('Withdrawal request error:', error);
      res.status(500).json({ error: "Failed to create withdrawal request" });
    }
  });

  // Get user transactions
  app.get("/api/transactions/:userId", async (req, res) => {
    try {
      const transactions = await storage.getUserTransactions(req.params.userId);
      res.json({ transactions });
    } catch (error) {
      console.error('Get transactions error:', error);
      res.status(500).json({ error: "Failed to get transactions" });
    }
  });

  return httpServer;
}
